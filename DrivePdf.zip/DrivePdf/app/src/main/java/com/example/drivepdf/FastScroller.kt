package com.example.drivepdf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.google.android.material.color.MaterialColors

/**
 * Drive-style fast scroller: a slim handle on the right edge that appears while you scroll.
 * Drag it to fly through the document; a bubble shows the page number.
 * It only grabs touches that start on the handle, everything else passes through to the PDF.
 */
class FastScroller @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Called with 0..1 while dragging; returns the text for the page bubble. */
    var onDrag: ((Float) -> String)? = null

    var dragging = false
        private set

    var rightInset = 0
        set(v) {
            field = v
            invalidate()
        }

    var bottomInset = 0
        set(v) {
            field = v
            invalidate()
        }

    private val d = resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    private var fraction = 0f
    private var label = ""
    private var available = false
    private var shown = false
    private var grab = 0f

    private val primary = MaterialColors.getColor(
        context, com.google.android.material.R.attr.colorPrimary, Color.BLUE
    )
    private val onPrimary = MaterialColors.getColor(
        context, com.google.android.material.R.attr.colorOnPrimary, Color.WHITE
    )
    private val idle = MaterialColors.getColor(
        context, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY
    )

    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = primary }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = onPrimary
        textSize = 14 * d
        typeface = Typeface.DEFAULT_BOLD
    }

    private val hideRun = Runnable {
        if (!dragging) {
            shown = false
            animate().alpha(0f).setDuration(250).start()
        }
    }

    private val thumbH: Float get() = 56 * d
    private val trackTop: Float get() = 8 * d
    private val trackH: Float get() = height - 16 * d - bottomInset
    private fun thumbTop(): Float = trackTop + fraction * (trackH - thumbH).coerceAtLeast(0f)

    init {
        alpha = 0f
    }

    /** Move the handle to match the scroll position (ignored while you are dragging it). */
    fun update(f: Float, text: String, scrollable: Boolean) {
        available = scrollable
        if (dragging) return
        fraction = f.coerceIn(0f, 1f)
        label = text
        invalidate()
    }

    /** Show the handle for a moment. */
    fun flash() {
        if (!available) return
        shown = true
        animate().cancel()
        animate().alpha(1f).setDuration(120).start()
        handler.removeCallbacks(hideRun)
        if (!dragging) handler.postDelayed(hideRun, 1400)
    }

    fun hideNow() {
        handler.removeCallbacks(hideRun)
        shown = false
        dragging = false
        available = false
        animate().cancel()
        alpha = 0f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!shown || !available) return false
                val right = width - 4 * d - rightInset
                val top = thumbTop()
                if (e.x < right - 36 * d || e.x > right + 6 * d) return false
                if (e.y < top - 16 * d || e.y > top + thumbH + 16 * d) return false
                dragging = true
                grab = e.y - top
                handler.removeCallbacks(hideRun)
                parent.requestDisallowInterceptTouchEvent(true)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                val span = (trackH - thumbH).coerceAtLeast(1f)
                fraction = ((e.y - grab - trackTop) / span).coerceIn(0f, 1f)
                label = onDrag?.invoke(fraction) ?: label
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) return false
                dragging = false
                invalidate()
                flash()
                return true
            }
        }
        return false
    }

    override fun onDraw(canvas: Canvas) {
        if (!available && !dragging) return
        val tw = if (dragging) 10 * d else 6 * d
        val right = width - 4 * d - rightInset
        val left = right - tw
        val top = thumbTop()

        thumbPaint.color = if (dragging) primary else idle
        thumbPaint.alpha = if (dragging) 255 else 200
        canvas.drawRoundRect(left, top, right, top + thumbH, tw / 2, tw / 2, thumbPaint)

        if (dragging && label.isNotEmpty()) {
            val padH = 14 * d
            val bh = 36 * d
            val bw = textPaint.measureText(label) + 2 * padH
            val bRight = left - 12 * d
            val bLeft = bRight - bw
            val maxTop = (height - bh - 4 * d).coerceAtLeast(4 * d)
            val bTop = (top + thumbH / 2 - bh / 2).coerceIn(4 * d, maxTop)
            canvas.drawRoundRect(bLeft, bTop, bRight, bTop + bh, bh / 2, bh / 2, bubblePaint)
            val fm = textPaint.fontMetrics
            canvas.drawText(label, bLeft + padH, bTop + bh / 2 - (fm.ascent + fm.descent) / 2, textPaint)
        }
    }
}
