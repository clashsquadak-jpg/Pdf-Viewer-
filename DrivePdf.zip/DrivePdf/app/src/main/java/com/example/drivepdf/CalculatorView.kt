package com.example.drivepdf

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.widget.TextViewCompat
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

/**
 * A small, modern calculator with history and memory (MC MR M+ M- MS).
 * History and memory are remembered between app launches.
 */
@SuppressLint("ClickableViewAccessibility")
class CalculatorView(context: Context) : LinearLayout(context) {

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = (v * d).toInt()
    private val prefs = context.getSharedPreferences("calc", Context.MODE_PRIVATE)

    private val cBg = context.getColor(R.color.calc_bg)
    private val cKey = context.getColor(R.color.calc_key)
    private val cFn = context.getColor(R.color.calc_fn)
    private val cOp = context.getColor(R.color.calc_op)
    private val cOpText = context.getColor(R.color.calc_op_text)
    private val cEq = context.getColor(R.color.calc_eq)
    private val cEqText = context.getColor(R.color.calc_eq_text)
    private val cText = context.getColor(R.color.calc_text)
    private val cDim = context.getColor(R.color.calc_text_dim)

    private class Entry(val expr: String, val result: String)

    // ----- state -----
    private val tokens = ArrayList<String>() // numbers and operators, already confirmed
    private var entry = ""                   // the number being typed (or the last result)
    private var justEvaluated = false
    private var freshEntry = false           // next digit replaces the entry (after memory keys)
    private var error = false
    private var lastExpr = ""
    private var memory = BigDecimal.ZERO
    private val history = ArrayList<Entry>() // newest first

    // ----- views -----
    private val exprView = TextView(context)
    private val resultView = TextView(context)
    private val memBadge = TextView(context)
    private val historyChip = TextView(context)
    private val mainCol = LinearLayout(context)
    private val historyPanel = LinearLayout(context)
    private val historyList = LinearLayout(context)
    private val historyEmpty = TextView(context)
    private var historyOpen = false

    init {
        orientation = VERTICAL
        setBackgroundColor(cBg)
        isClickable = true
        setPadding(dp(8f), dp(6f), dp(8f), dp(8f))
        loadState()

        // ---- top bar: history toggle + memory badge ----
        val top = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        styleChip(historyChip, "History")
        historyChip.setOnClickListener {
            tap(it)
            setHistoryOpen(!historyOpen)
        }
        top.addView(historyChip, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30f)))
        top.addView(View(context), LayoutParams(0, 1, 1f))
        memBadge.apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(cOpText)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
        }
        top.addView(memBadge, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(top, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34f)))

        // ---- body ----
        val body = FrameLayout(context)
        addView(body, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        mainCol.orientation = VERTICAL
        body.addView(mainCol, FrameLayout.LayoutParams(-1, -1))
        buildMain()

        historyPanel.orientation = VERTICAL
        historyPanel.visibility = View.GONE
        historyPanel.setBackgroundColor(cBg)
        body.addView(historyPanel, FrameLayout.LayoutParams(-1, -1))
        buildHistoryPanel()

        refresh()
    }

    // ---------------------------------------------------------------- UI building

    private fun buildMain() {
        // display
        val display = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(8f), 0, dp(8f), dp(4f))
        }
        exprView.apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(cDim)
            gravity = Gravity.END
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.START
        }
        resultView.apply {
            setTextColor(cText)
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 1
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 44f)
            TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                this, 18, 44, 1, TypedValue.COMPLEX_UNIT_SP
            )
        }
        display.addView(exprView, LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        display.addView(resultView, LayoutParams(-1, 0, 1f))
        mainCol.addView(display, LayoutParams(-1, 0, 1.3f))

        // memory row
        val mem = LinearLayout(context).apply { orientation = HORIZONTAL }
        for ((label, act) in listOf<Pair<String, () -> Unit>>(
            "MC" to { memClear() },
            "MR" to { memRecall() },
            "M+" to { memAdd(false) },
            "M\u2212" to { memAdd(true) },
            "MS" to { memStore() }
        )) {
            mem.addView(key(label, 0, cDim, 14f, act, flat = true))
        }
        mainCol.addView(mem, LayoutParams(-1, dp(34f)))

        // keypad
        val rows = listOf(
            listOf("AC", "\u232B", "%", "\u00F7"),
            listOf("7", "8", "9", "\u00D7"),
            listOf("4", "5", "6", "\u2212"),
            listOf("1", "2", "3", "+"),
            listOf("\u00B1", "0", ".", "=")
        )
        for (r in rows) {
            val row = LinearLayout(context).apply { orientation = HORIZONTAL }
            for (k in r) row.addView(keyFor(k))
            mainCol.addView(row, LayoutParams(-1, 0, 1f))
        }
    }

    private fun keyFor(k: String): View = when (k) {
        "AC" -> key(k, cFn, cText, 20f, { clearAll() })
        "\u232B" -> key(k, cFn, cText, 20f, { backspace() })
        "%" -> key(k, cFn, cText, 20f, { percent() })
        "\u00F7", "\u00D7", "\u2212", "+" -> key(k, cOp, cOpText, 24f, { operator(k) })
        "=" -> key(k, cEq, cEqText, 26f, { equals() })
        "\u00B1" -> key(k, cKey, cText, 20f, { negate() })
        "." -> key(k, cKey, cText, 24f, { dot() })
        else -> key(k, cKey, cText, 24f, { digit(k) })
    }

    private fun buildHistoryPanel() {
        val header = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8f), 0, dp(4f), 0)
        }
        val title = TextView(context).apply {
            text = "History"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(cText)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val clear = TextView(context)
        styleChip(clear, "Clear")
        clear.setOnClickListener {
            tap(it)
            history.clear()
            saveState()
            rebuildHistory()
        }
        header.addView(title, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(clear, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30f)))
        historyPanel.addView(header, LayoutParams(-1, dp(40f)))

        val scroll = ScrollView(context).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = OVER_SCROLL_NEVER
        }
        historyList.orientation = VERTICAL
        scroll.addView(historyList, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        historyPanel.addView(scroll, LayoutParams(-1, 0, 1f))

        historyEmpty.apply {
            text = "No calculations yet"
            setTextColor(cDim)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            setPadding(0, dp(32f), 0, 0)
        }
        rebuildHistory()
    }

    private fun rebuildHistory() {
        historyList.removeAllViews()
        if (history.isEmpty()) {
            (historyEmpty.parent as? ViewGroup)?.removeView(historyEmpty)
            historyList.addView(historyEmpty, LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        for (h in history) {
            val row = LinearLayout(context).apply {
                orientation = VERTICAL
                gravity = Gravity.END
                setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
                background = ripple(0, dp(12f))
                isClickable = true
                setOnClickListener {
                    tap(it)
                    // bring the old result back so you can keep calculating with it
                    tokens.clear()
                    entry = h.result
                    justEvaluated = true
                    freshEntry = false
                    error = false
                    lastExpr = ""
                    setHistoryOpen(false)
                    refresh()
                }
            }
            row.addView(TextView(context).apply {
                text = h.expr + " ="
                setTextColor(cDim)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                gravity = Gravity.END
            })
            row.addView(TextView(context).apply {
                text = pretty(h.result)
                setTextColor(cText)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                gravity = Gravity.END
            })
            historyList.addView(row, LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun setHistoryOpen(open: Boolean) {
        historyOpen = open
        historyChip.text = if (open) "Keypad" else "History"
        if (open) {
            rebuildHistory()
            historyPanel.alpha = 0f
            historyPanel.visibility = View.VISIBLE
            historyPanel.animate().alpha(1f).setDuration(140).start()
        } else {
            historyPanel.animate().cancel()
            historyPanel.visibility = View.GONE
        }
    }

    private fun styleChip(tv: TextView, label: String) {
        tv.apply {
            text = label
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(cText)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(dp(14f), 0, dp(14f), 0)
            background = ripple(cFn, dp(15f))
            isClickable = true
        }
    }

    private fun ripple(fill: Int, radius: Int): RippleDrawable {
        val shape = GradientDrawable().apply {
            cornerRadius = radius.toFloat()
            setColor(fill)
        }
        val rc = (cText and 0x00FFFFFF) or (0x22 shl 24)
        return RippleDrawable(ColorStateList.valueOf(rc), shape, null)
    }

    private fun tap(v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun key(
        label: String, fill: Int, fg: Int, sp: Float,
        action: () -> Unit, flat: Boolean = false
    ): TextView = TextView(context).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(fg)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        maxLines = 1
        TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
            this, 10, sp.toInt(), 1, TypedValue.COMPLEX_UNIT_SP
        )
        background = ripple(if (flat) 0 else fill, dp(if (flat) 10f else 18f))
        isClickable = true
        isFocusable = true
        setOnClickListener {
            tap(it)
            action()
        }
        // tiny "press in" feel; returns false so the click still goes through
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
            }
            false
        }
        layoutParams = LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
            val m = dp(3f)
            setMargins(m, m, m, m)
        }
    }

    // ---------------------------------------------------------------- calculator logic

    private fun isOp(s: String) = s == "+" || s == "\u2212" || s == "\u00D7" || s == "\u00F7"

    private fun resetIfError() {
        if (error) {
            tokens.clear()
            entry = ""
            justEvaluated = false
            freshEntry = false
            error = false
            lastExpr = ""
        }
    }

    private fun digit(c: String) {
        resetIfError()
        if (justEvaluated) {
            tokens.clear(); entry = ""; justEvaluated = false; lastExpr = ""
        }
        if (freshEntry) {
            entry = ""; freshEntry = false
        }
        val digits = entry.count { it.isDigit() }
        if (digits >= 15) return
        entry = when (entry) {
            "0" -> c
            "-0" -> "-$c"
            else -> entry + c
        }
        refresh()
    }

    private fun dot() {
        resetIfError()
        if (justEvaluated) {
            tokens.clear(); entry = ""; justEvaluated = false; lastExpr = ""
        }
        if (freshEntry) {
            entry = ""; freshEntry = false
        }
        if (entry.contains('.')) return
        entry = if (entry.isEmpty()) "0." else if (entry == "-") "-0." else "$entry."
        refresh()
    }

    private fun operator(op: String) {
        resetIfError()
        if (justEvaluated) {
            justEvaluated = false
            lastExpr = ""
        }
        freshEntry = false
        when {
            entry.isNotEmpty() -> {
                tokens.add(clean(entry))
                tokens.add(op)
                entry = ""
            }
            tokens.isNotEmpty() -> {
                if (isOp(tokens.last())) tokens[tokens.size - 1] = op else tokens.add(op)
            }
            else -> {
                tokens.add("0")
                tokens.add(op)
            }
        }
        refresh()
    }

    private fun equals() {
        resetIfError()
        val list = ArrayList<String>(tokens)
        if (entry.isNotEmpty()) list.add(clean(entry))
        if (list.isNotEmpty() && isOp(list.last())) list.removeAt(list.size - 1)
        if (list.isEmpty()) return
        if (list.size == 1) {
            // nothing to calculate, just settle on the number
            entry = list[0]
            tokens.clear()
            justEvaluated = true
            lastExpr = ""
            refresh()
            return
        }
        val exprText = list.joinToString(" ") { if (isOp(it)) it else pretty(it) }
        try {
            val res = format(eval(list))
            history.add(0, Entry(exprText, res))
            while (history.size > 100) history.removeAt(history.size - 1)
            saveState()
            tokens.clear()
            entry = res
            justEvaluated = true
            freshEntry = false
            lastExpr = exprText
        } catch (e: ArithmeticException) {
            tokens.clear()
            entry = ""
            error = true
            lastExpr = exprText
        }
        refresh()
    }

    private fun negate() {
        resetIfError()
        if (entry.isEmpty()) entry = "0"
        entry = if (entry.startsWith("-")) entry.substring(1) else "-$entry"
        freshEntry = false
        refresh()
    }

    private fun percent() {
        resetIfError()
        if (entry.isEmpty()) return
        val n = num(entry)
        val hundred = BigDecimal(100)
        val r = if (tokens.size >= 2 && (tokens.last() == "+" || tokens.last() == "\u2212")) {
            // 200 + 10%  ->  200 + 20
            val base = try {
                eval(tokens.subList(0, tokens.size - 1))
            } catch (e: ArithmeticException) {
                BigDecimal.ZERO
            }
            base.multiply(n).divide(hundred, MathContext(20))
        } else {
            n.divide(hundred, MathContext(20))
        }
        entry = format(r)
        freshEntry = false
        refresh()
    }

    private fun backspace() {
        if (error) {
            resetIfError(); refresh(); return
        }
        if (justEvaluated) {
            // dropping a digit from a result turns it into something you are typing again
            justEvaluated = false
            lastExpr = ""
        }
        freshEntry = false
        if (entry.isNotEmpty()) {
            entry = entry.dropLast(1)
            if (entry == "-") entry = ""
        } else if (tokens.isNotEmpty()) {
            tokens.removeAt(tokens.size - 1) // the operator
            if (tokens.isNotEmpty()) entry = tokens.removeAt(tokens.size - 1)
        }
        refresh()
    }

    private fun clearAll() {
        tokens.clear()
        entry = ""
        justEvaluated = false
        freshEntry = false
        error = false
        lastExpr = ""
        refresh()
    }

    // ---- memory ----

    /** The number currently "on the display". */
    private fun currentValue(): BigDecimal {
        if (entry.isNotEmpty()) return num(entry)
        val list = ArrayList<String>(tokens)
        if (list.isNotEmpty() && isOp(list.last())) list.removeAt(list.size - 1)
        if (list.isEmpty()) return BigDecimal.ZERO
        return try {
            eval(list)
        } catch (e: ArithmeticException) {
            BigDecimal.ZERO
        }
    }

    private fun memClear() {
        memory = BigDecimal.ZERO
        saveState()
        refresh()
    }

    private fun memRecall() {
        resetIfError()
        if (justEvaluated) {
            tokens.clear(); justEvaluated = false; lastExpr = ""
        }
        entry = format(memory)
        freshEntry = true
        refresh()
    }

    private fun memAdd(subtract: Boolean) {
        resetIfError()
        val v = currentValue()
        memory = if (subtract) memory.subtract(v) else memory.add(v)
        freshEntry = true
        saveState()
        refresh()
    }

    private fun memStore() {
        resetIfError()
        memory = currentValue()
        freshEntry = true
        saveState()
        refresh()
    }

    // ---- math helpers ----

    private fun num(s: String): BigDecimal = try {
        BigDecimal(clean(s))
    } catch (e: NumberFormatException) {
        BigDecimal.ZERO
    }

    /** "5." -> "5", "-0." -> "-0" */
    private fun clean(s: String) = if (s.endsWith(".")) s.dropLast(1) else s

    private fun eval(list: List<String>): BigDecimal {
        val nums = ArrayList<BigDecimal>()
        val ops = ArrayList<String>()
        nums.add(num(list[0]))
        var i = 1
        while (i + 1 < list.size) {
            ops.add(list[i])
            nums.add(num(list[i + 1]))
            i += 2
        }
        var k = 0
        while (k < ops.size) {
            if (ops[k] == "\u00D7" || ops[k] == "\u00F7") {
                val a = nums[k]
                val b = nums[k + 1]
                val r = if (ops[k] == "\u00D7") a.multiply(b) else {
                    if (b.signum() == 0) throw ArithmeticException("div by zero")
                    a.divide(b, MathContext(20, RoundingMode.HALF_EVEN))
                }
                nums[k] = r
                nums.removeAt(k + 1)
                ops.removeAt(k)
            } else {
                k++
            }
        }
        var res = nums[0]
        for (j in ops.indices) {
            res = if (ops[j] == "+") res.add(nums[j + 1]) else res.subtract(nums[j + 1])
        }
        return res
    }

    private fun format(v: BigDecimal): String {
        val r = v.round(MathContext(15, RoundingMode.HALF_EVEN)).stripTrailingZeros()
        if (r.signum() == 0) return "0"
        val a = r.abs()
        return if (a >= BigDecimal("1E15") || a < BigDecimal("1E-9")) {
            r.round(MathContext(10)).toString()
        } else {
            r.toPlainString()
        }
    }

    /** 1234567.8 -> 1,234,567.8 */
    private fun pretty(s: String): String {
        if (s.isEmpty()) return "0"
        var t = s
        var neg = false
        if (t.startsWith("-")) {
            neg = true
            t = t.substring(1)
        }
        if (t.contains('E') || t.contains('e')) return s
        val dot = t.indexOf('.')
        val ip = if (dot >= 0) t.substring(0, dot) else t
        val fp = if (dot >= 0) t.substring(dot) else ""
        val grouped = if (ip.isEmpty()) "0" else ip.reversed().chunked(3).joinToString(",").reversed()
        return (if (neg) "-" else "") + grouped + fp
    }

    // ---------------------------------------------------------------- display + storage

    private fun refresh() {
        resultView.text = when {
            error -> "Error"
            entry.isNotEmpty() -> pretty(entry)
            tokens.isNotEmpty() -> pretty(format(currentValue()))
            else -> "0"
        }
        exprView.text = when {
            error -> lastExpr
            justEvaluated -> if (lastExpr.isEmpty()) "" else "$lastExpr ="
            else -> tokens.joinToString(" ") { if (isOp(it)) it else pretty(it) }
        }
        val hasMem = memory.signum() != 0
        memBadge.text = if (hasMem) "M  " + pretty(format(memory)) else ""
    }

    private fun saveState() {
        try {
            val arr = JSONArray()
            for (h in history) arr.put(JSONObject().put("e", h.expr).put("r", h.result))
            prefs.edit()
                .putString("mem", memory.toPlainString())
                .putString("hist", arr.toString())
                .apply()
        } catch (_: Exception) {
        }
    }

    private fun loadState() {
        try {
            memory = BigDecimal(prefs.getString("mem", "0") ?: "0")
            val arr = JSONArray(prefs.getString("hist", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                history.add(Entry(o.getString("e"), o.getString("r")))
            }
        } catch (_: Exception) {
            memory = BigDecimal.ZERO
            history.clear()
        }
    }
}
