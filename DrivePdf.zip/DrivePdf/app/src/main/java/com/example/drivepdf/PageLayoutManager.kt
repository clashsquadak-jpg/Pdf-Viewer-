package com.example.drivepdf

import android.content.Context
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Binds pages about 3/4 of a screen before they scroll into view, so rendering starts early
 * and pages are already sharp when they arrive.
 */
class PageLayoutManager(context: Context) : LinearLayoutManager(context) {
    override fun calculateExtraLayoutSpace(state: RecyclerView.State, extraLayoutSpace: IntArray) {
        val e = (height * 0.75f).toInt()
        extraLayoutSpace[0] = e
        extraLayoutSpace[1] = e
    }
}
