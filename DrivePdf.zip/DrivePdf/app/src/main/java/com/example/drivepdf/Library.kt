package com.example.drivepdf

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/** Keeps copies of recently opened PDFs inside the app, and remembers which were open together. */
class Library(context: Context) {

    class Session(
        val keys: List<String>,
        val names: List<String>,
        val ratio: Float,
        /** page each PDF was on (same order as keys); empty = unknown */
        val pages: List<Int> = emptyList()
    )

    private val prefs = context.getSharedPreferences("library", Context.MODE_PRIVATE)
    private val dir = File(context.filesDir, "docs").apply { mkdirs() }

    fun fileFor(key: String) = File(dir, "$key.pdf")

    fun nameOf(key: String): String = prefs.getString("name_$key", null) ?: "document.pdf"

    /** Copies the PDF into app storage. The same PDF is only stored once. */
    fun importPdf(input: InputStream, displayName: String): File {
        val tmp = File(dir, "tmp_${System.nanoTime()}")
        tmp.outputStream().use { o -> input.copyTo(o, 256 * 1024) }
        val key = hash(tmp)
        val target = fileFor(key)
        if (target.exists()) {
            tmp.delete()
        } else if (!tmp.renameTo(target)) {
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
        target.setLastModified(System.currentTimeMillis())
        prefs.edit().putString("name_$key", displayName).apply()
        return target
    }

    private fun hash(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(f.length().toString().toByteArray())
        f.inputStream().use { input ->
            val buf = ByteArray(8192)
            var left = 256 * 1024
            while (left > 0) {
                val n = input.read(buf, 0, minOf(buf.size, left))
                if (n <= 0) break
                md.update(buf, 0, n)
                left -= n
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Most recent first. Sessions whose files are gone are skipped. */
    fun sessions(): List<Session> {
        val out = ArrayList<Session>()
        try {
            val arr = JSONArray(prefs.getString("sessions", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ka = o.getJSONArray("keys")
                val keys = List(ka.length()) { ka.getString(it) }
                if (keys.isEmpty() || keys.any { !fileFor(it).exists() }) continue
                val pa = o.optJSONArray("pages")
                val pages = if (pa != null && pa.length() == keys.size) List(pa.length()) { pa.getInt(it) } else emptyList()
                out.add(Session(keys, keys.map { nameOf(it) }, o.optDouble("ratio", 0.5).toFloat(), pages))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun saveSession(s: Session) {
        val list = sessions().filter { it.keys != s.keys }.toMutableList()
        list.add(0, s)
        val kept = list.take(8)
        val arr = JSONArray()
        for (x in kept) {
            arr.put(
                JSONObject().put("keys", JSONArray(x.keys)).put("ratio", x.ratio.toDouble())
                    .put("pages", JSONArray(x.pages))
            )
        }
        prefs.edit().putString("sessions", arr.toString()).apply()

        // delete stored PDFs that are no longer in any recent session
        val keepKeys = kept.flatMap { it.keys }.toSet()
        val now = System.currentTimeMillis()
        dir.listFiles()?.forEach { f ->
            val old = now - f.lastModified() > 120_000
            if (f.name.endsWith(".pdf") && f.nameWithoutExtension !in keepKeys && old) f.delete()
            if (f.name.startsWith("tmp_") && now - f.lastModified() > 600_000) f.delete()
        }
    }
}
