package com.example.drivepdf

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var library: Library
    private lateinit var splitView: SplitLayout
    private lateinit var paneA: PdfPane
    private lateinit var paneB: PdfPane
    private lateinit var progress: View
    private lateinit var home: View
    private lateinit var recentTitle: View
    private lateinit var recentList: LinearLayout
    private lateinit var controls: View
    private lateinit var splitBtn: View
    private lateinit var backCallback: OnBackPressedCallback

    private val handler = Handler(Looper.getMainLooper())
    private val hideControls = Runnable { setControls(false) }
    private val settings by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    private var busy = false
    private var controlsOn = false
    private var pickForSecond = false
    private var pendingSplit: PdfPane? = null

    /** The pane on the left (or the only one when not split). */
    private val primary: PdfPane get() = splitView.left

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openUri(uri, pickForSecond)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        library = Library(this)
        applyOrientation()
        setContentView(R.layout.activity_main)

        splitView = findViewById(R.id.split)
        paneA = findViewById(R.id.paneA)
        paneB = findViewById(R.id.paneB)
        progress = findViewById(R.id.progress)
        home = findViewById(R.id.home)
        recentTitle = findViewById(R.id.recentTitle)
        recentList = findViewById(R.id.recentList)
        controls = findViewById(R.id.controls)
        splitBtn = findViewById(R.id.splitBtn)

        backCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                goHome()
            }
        }
        onBackPressedDispatcher.addCallback(this, backCallback)

        findViewById<View>(R.id.openButton).setOnClickListener {
            pickForSecond = false
            picker.launch(arrayOf("application/pdf"))
        }
        findViewById<View>(R.id.emptySettingsButton).setOnClickListener { showSettings() }
        findViewById<View>(R.id.settingsBtn).setOnClickListener { showSettings() }
        findViewById<View>(R.id.homeBtn).setOnClickListener { goHome() }
        splitBtn.setOnClickListener {
            pickForSecond = true
            setControls(false)
            picker.launch(arrayOf("application/pdf"))
        }

        val loaded = { p: PdfPane ->
            setBusy(false)
            if (p === pendingSplit) {
                pendingSplit = null
                splitView.setSplit(true)
            }
            saveSession()
            updateHome()
        }
        val failed = { p: PdfPane, msg: String ->
            setBusy(false)
            toast(msg)
            if (p === pendingSplit) pendingSplit = null
            if (splitView.split && !p.hasDoc) {
                splitView.showOnly(if (p === paneA) paneB else paneA)
            }
            updateHome()
        }
        for (p in listOf(paneA, paneB)) {
            p.onTap = { setControls(!controlsOn) }
            p.onLoaded = loaded
            p.onFailed = failed
            p.onClose = { closePane(p) }
        }

        val keys = savedInstanceState?.getStringArrayList("keys")
        val data = intent?.data
        if (keys != null && keys.isNotEmpty()) {
            val ratio = savedInstanceState?.getFloat("ratio", 0.5f) ?: 0.5f
            openSession(Library.Session(keys, emptyList(), ratio))
        } else if (intent?.action == Intent.ACTION_VIEW && data != null) {
            openUri(data, false)
        } else {
            // open the last thing you were reading
            val last = library.sessions().firstOrNull()
            if (last != null) openSession(last) else updateHome()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val data = intent.data
        if (intent.action == Intent.ACTION_VIEW && data != null) openUri(data, false)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        currentSession()?.let {
            outState.putStringArrayList("keys", ArrayList(it.keys))
            outState.putFloat("ratio", it.ratio)
        }
    }

    override fun onPause() {
        super.onPause()
        paneA.saveProgress()
        paneB.saveProgress()
        saveSession()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        paneA.release()
        paneB.release()
    }

    // ---------- opening files ----------

    private fun openUri(uri: Uri, asSecond: Boolean) {
        setBusy(true)
        Exec.io.execute {
            try {
                val name = queryName(uri)
                val file = contentResolver.openInputStream(uri)!!.use { library.importPdf(it, name) }
                runOnUiThread {
                    if (asSecond) {
                        pendingSplit = splitView.right
                        splitView.right.load(file, null)
                    } else {
                        splitView.left.load(file, null)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false)
                    toast("Couldn't open this file")
                }
            }
        }
    }

    private fun queryName(uri: Uri): String {
        var name: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) name = c.getString(0) }
        } catch (_: Exception) {
        }
        val raw = name?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: "document.pdf"
        var s = raw.substringAfterLast('/').replace(Regex("[\\\\:*?\"<>|]"), "_")
        if (!s.lowercase().endsWith(".pdf")) s += ".pdf"
        return s
    }

    private fun openSession(s: Library.Session) {
        val files = s.keys.map { library.fileFor(it) }
        if (files.isEmpty() || files.any { !it.exists() }) {
            toast("That PDF is no longer available")
            updateHome()
            return
        }
        setBusy(true)
        pendingSplit = null
        clearAll()
        if (files.size >= 2) {
            splitView.setSplit(true, s.ratio)
            paneA.load(files[0], null)
            paneB.load(files[1], null)
        } else {
            paneA.load(files[0], null)
        }
    }

    private fun clearAll() {
        paneA.clear()
        paneB.clear()
        splitView.showOnly(paneA)
    }

    // ---------- recent list / home ----------

    private fun currentSession(): Library.Session? {
        val k1 = primary.key ?: return null
        val keys = mutableListOf(k1)
        var ratio = 0.5f
        if (splitView.split) {
            val k2 = splitView.right.key ?: return null // second PDF still loading
            keys.add(k2)
            ratio = splitView.ratio
        }
        return Library.Session(keys, keys.map { library.nameOf(it) }, ratio)
    }

    private fun saveSession() {
        currentSession()?.let { library.saveSession(it) }
    }

    private fun goHome() {
        setControls(false)
        paneA.saveProgress()
        paneB.saveProgress()
        saveSession()
        pendingSplit = null
        clearAll()
        updateHome()
    }

    private fun updateHome() {
        val show = !primary.hasDoc && !busy
        home.visibility = if (show) View.VISIBLE else View.GONE
        backCallback.isEnabled = primary.hasDoc
        if (show) buildRecents()
    }

    private fun buildRecents() {
        recentList.removeAllViews()
        val list = library.sessions()
        recentTitle.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        for (s in list) addRow(s)
    }

    private fun addRow(s: Library.Session) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setBackgroundResource(R.drawable.row_bg)
        row.setPadding(dp(16), dp(14), dp(16), dp(14))
        row.isClickable = true
        val tv = TypedValue()
        if (theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) {
            row.foreground = ContextCompat.getDrawable(this, tv.resourceId)
        }

        val title = TextView(this)
        title.text = s.names.joinToString("   +   ")
        title.textSize = 16f
        title.maxLines = 2
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        title.setTypeface(null, Typeface.BOLD)
        row.addView(title)

        val sub = TextView(this)
        sub.text = if (s.keys.size > 1) "Split view \u00B7 ${s.keys.size} PDFs" else "PDF"
        sub.textSize = 12f
        sub.alpha = 0.6f
        row.addView(sub)

        row.setOnClickListener { openSession(s) }

        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(8)
        recentList.addView(row, lp)
    }

    // ---------- split view ----------

    private fun closePane(p: PdfPane) {
        if (!splitView.split) return
        setControls(false)
        val other = if (p === paneA) paneB else paneA
        p.clear()
        splitView.showOnly(other)
        saveSession()
    }

    // ---------- controls & settings ----------

    private fun setControls(on: Boolean) {
        handler.removeCallbacks(hideControls)
        if (on && !primary.hasDoc) return
        controlsOn = on
        splitBtn.visibility = if (splitView.split) View.GONE else View.VISIBLE
        controls.fadeTo(on)
        paneA.showControls(on, splitView.split)
        paneB.showControls(on, splitView.split)
        if (on) handler.postDelayed(hideControls, 3000)
    }

    private fun applyOrientation() {
        requestedOrientation = when (settings.getString("orientation", "auto")) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun showSettings() {
        val values = arrayOf("auto", "portrait", "landscape")
        val labels = arrayOf("Auto-rotate", "Portrait", "Landscape")
        val current = values.indexOf(settings.getString("orientation", "auto")).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Settings: screen orientation")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                settings.edit().putString("orientation", values[which]).apply()
                applyOrientation()
                dialog.dismiss()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun setBusy(b: Boolean) {
        busy = b
        progress.visibility = if (b) View.VISIBLE else View.GONE
        updateHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
