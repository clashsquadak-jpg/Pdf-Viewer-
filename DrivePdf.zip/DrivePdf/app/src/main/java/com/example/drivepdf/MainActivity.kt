package com.example.drivepdf

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var splitView: SplitLayout
    private lateinit var paneA: PdfPane
    private lateinit var paneB: PdfPane
    private lateinit var progress: View
    private lateinit var empty: View
    private lateinit var controls: View
    private lateinit var splitBtn: View
    private lateinit var pickTarget: PdfPane

    private val handler = Handler(Looper.getMainLooper())
    private val hideControls = Runnable { setControls(false) }
    private val settings by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var busy = false
    private var controlsOn = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openUri(uri, pickTarget)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyOrientation()
        setContentView(R.layout.activity_main)

        splitView = findViewById(R.id.split)
        paneA = findViewById(R.id.paneA)
        paneB = findViewById(R.id.paneB)
        progress = findViewById(R.id.progress)
        empty = findViewById(R.id.empty)
        controls = findViewById(R.id.controls)
        splitBtn = findViewById(R.id.splitBtn)
        pickTarget = paneA

        findViewById<View>(R.id.openButton).setOnClickListener {
            pickTarget = paneA
            picker.launch(arrayOf("application/pdf"))
        }
        findViewById<View>(R.id.emptySettingsButton).setOnClickListener { showSettings() }
        findViewById<View>(R.id.settingsBtn).setOnClickListener { showSettings() }
        splitBtn.setOnClickListener {
            pickTarget = paneB
            setControls(false)
            picker.launch(arrayOf("application/pdf"))
        }

        paneA.onTap = { setControls(!controlsOn) }
        paneB.onTap = { setControls(!controlsOn) }
        paneA.onLoaded = { setBusy(false) }
        paneB.onLoaded = {
            setBusy(false)
            if (!splitView.split) splitView.setSplit(true)
        }
        paneA.onFailed = { msg ->
            setBusy(false)
            toast(msg)
        }
        paneB.onFailed = { msg ->
            setBusy(false)
            toast(msg)
            if (!paneB.hasDoc) splitView.setSplit(false)
        }
        paneA.onClose = { closePane(paneA) }
        paneB.onClose = { closePane(paneB) }

        val pathA = savedInstanceState?.getString("pathA")
        val pathB = savedInstanceState?.getString("pathB")
        if (pathA != null && File(pathA).exists()) {
            setBusy(true)
            paneA.load(File(pathA), savedInstanceState.getInt("pageA", 0))
            if (pathB != null && File(pathB).exists()) {
                splitView.setSplit(true, savedInstanceState.getFloat("ratio", 0.5f))
                paneB.load(File(pathB), savedInstanceState.getInt("pageB", 0))
            }
        } else {
            handleIntent(intent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        paneA.file?.let {
            outState.putString("pathA", it.absolutePath)
            outState.putInt("pageA", paneA.currentPage())
        }
        if (splitView.split) {
            paneB.file?.let {
                outState.putString("pathB", it.absolutePath)
                outState.putInt("pageB", paneB.currentPage())
                outState.putFloat("ratio", splitView.ratio)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        paneA.saveProgress()
        paneB.saveProgress()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        paneA.release()
        paneB.release()
    }

    // ---------- opening files ----------

    private fun handleIntent(i: Intent?) {
        val data = i?.data
        if (i?.action == Intent.ACTION_VIEW && data != null) openUri(data, paneA)
        else updateEmpty()
    }

    private fun openUri(uri: Uri, target: PdfPane) {
        setBusy(true)
        Exec.io.execute {
            try {
                val name = queryName(uri)
                val root = File(cacheDir, "pdfs")
                val dir = File(root, System.nanoTime().toString()).apply { mkdirs() }
                val out = File(dir, name)
                contentResolver.openInputStream(uri)!!.use { input ->
                    out.outputStream().use { o -> input.copyTo(o) }
                }
                val keep = listOfNotNull(paneA.file?.parentFile, paneB.file?.parentFile, dir)
                root.listFiles()?.filter { it !in keep }?.forEach { it.deleteRecursively() }
                target.load(out, null)
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false)
                    toast("Couldn't open this file")
                }
            }
        }
    }

    private fun queryName(uri: Uri): String {
        var name: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) name = c.getString(0) }
        } catch (_: Exception) {
        }
        val raw = name?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: "document.pdf"
        var s = raw.substringAfterLast('/').replace(Regex("[\\\\:*?\"<>|]"), "_")
        if (!s.lowercase().endsWith(".pdf")) s += ".pdf"
        return s
    }

    // ---------- split view ----------

    private fun closePane(p: PdfPane) {
        if (!splitView.split) return
        setControls(false)
        if (p === paneB) {
            paneB.clear()
            splitView.setSplit(false)
        } else {
            // closing the left PDF: the right one takes over the full screen
            val f = paneB.file
            val page = paneB.currentPage()
            paneA.clear()
            paneB.clear()
            splitView.setSplit(false)
            if (f != null) {
                setBusy(true)
                paneA.load(f, page)
            }
        }
    }

    // ---------- controls & settings ----------

    private fun setControls(on: Boolean) {
        handler.removeCallbacks(hideControls)
        if (on && !paneA.hasDoc) return
        controlsOn = on
        splitBtn.visibility = if (splitView.split) View.GONE else View.VISIBLE
        controls.fadeTo(on)
        paneA.showControls(on, splitView.split)
        paneB.showControls(on, splitView.split)
        if (on) handler.postDelayed(hideControls, 3000)
    }

    private fun applyOrientation() {
        requestedOrientation = when (settings.getString("orientation", "auto")) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun showSettings() {
        val values = arrayOf("auto", "portrait", "landscape")
        val labels = arrayOf("Auto-rotate", "Portrait", "Landscape")
        val current = values.indexOf(settings.getString("orientation", "auto")).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Settings: screen orientation")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                settings.edit().putString("orientation", values[which]).apply()
                applyOrientation()
                dialog.dismiss()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun setBusy(b: Boolean) {
        busy = b
        progress.visibility = if (b) View.VISIBLE else View.GONE
        updateEmpty()
    }

    private fun updateEmpty() {
        empty.visibility = if (paneA.hasDoc || busy) View.GONE else View.VISIBLE
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
