package com.example.drivepdf

import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var library: Library
    private lateinit var splitView: SplitLayout
    private lateinit var paneA: PdfPane
    private lateinit var paneB: PdfPane
    private lateinit var progress: View
    private lateinit var home: View
    private lateinit var recentTitle: View
    private lateinit var recentList: LinearLayout
    private lateinit var controls: View
    private lateinit var splitBtn: View
    private lateinit var backCallback: OnBackPressedCallback

    private val handler = Handler(Looper.getMainLooper())
    private val hideControls = Runnable { setControls(false) }
    private val settings by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    private var busy = false
    private var controlsOn = false
    private var pickForSecond = false
    private var pendingSplit: PdfPane? = null

    /** The pane on the left (or the only one when not split). */
    private val primary: PdfPane get() = splitView.left

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openUri(uri, pickForSecond)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        library = Library(this)
        applyOrientation()
        setupWindow()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById<View>(R.id.root)) { v, insets ->
            // keep content clear of whatever bars / notch are showing (none in landscape)
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(i.left, i.top, i.right, i.bottom)
            insets
        }
        updateSystemBars()

        splitView = findViewById(R.id.split)
        paneA = findViewById(R.id.paneA)
        paneB = findViewById(R.id.paneB)
        progress = findViewById(R.id.progress)
        home = findViewById(R.id.home)
        recentTitle = findViewById(R.id.recentTitle)
        recentList = findViewById(R.id.recentList)
        controls = findViewById(R.id.controls)
        splitBtn = findViewById(R.id.splitBtn)

        backCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                goHome()
            }
        }
        onBackPressedDispatcher.addCallback(this, backCallback)

        findViewById<View>(R.id.openButton).setOnClickListener {
            pickForSecond = false
            picker.launch(arrayOf("application/pdf"))
        }
        findViewById<View>(R.id.emptySettingsButton).setOnClickListener { showSettings() }
        findViewById<View>(R.id.settingsBtn).setOnClickListener { showSettings() }
        findViewById<View>(R.id.homeBtn).setOnClickListener { goHome() }
        splitBtn.setOnClickListener {
            pickForSecond = true
            setControls(false)
            picker.launch(arrayOf("application/pdf"))
        }

        val loaded = { p: PdfPane ->
            setBusy(false)
            if (p === pendingSplit) {
                pendingSplit = null
                splitView.setSplit(true)
            }
            saveSession(async = true)
            updateHome()
        }
        val failed = { p: PdfPane, msg: String ->
            setBusy(false)
            toast(msg)
            if (p === pendingSplit) pendingSplit = null
            if (splitView.split && !p.hasDoc) {
                splitView.showOnly(if (p === paneA) paneB else paneA)
            }
            updateHome()
        }
        for (p in listOf(paneA, paneB)) {
            p.onTap = { setControls(!controlsOn) }
            p.onLoaded = loaded
            p.onFailed = failed
            p.onClose = { closePane(p) }
        }

        val keys = savedInstanceState?.getStringArrayList("keys")
        val savedPages = savedInstanceState?.getIntegerArrayList("pages")
        val data = intent?.data
        if (keys != null && keys.isNotEmpty()) {
            val ratio = savedInstanceState?.getFloat("ratio", 0.5f) ?: 0.5f
            openSession(Library.Session(keys, emptyList(), ratio, savedPages ?: emptyList()))
        } else if (intent?.action == Intent.ACTION_VIEW && data != null) {
            openUri(data, false)
        } else {
            // open the last thing you were reading
            val last = library.sessions().firstOrNull()
            if (last != null) openSession(last) else updateHome()
        }
    }

    /** Draw edge to edge, also into the notch area. */
    private fun setupWindow() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
    }

    /** Landscape: hide the status and navigation bars (swipe from the edge to peek). Portrait: show them. */
    private fun updateSystemBars() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (landscape) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
        ViewCompat.requestApplyInsets(window.decorView)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateSystemBars()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) updateSystemBars()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val data = intent.data
        if (intent.action == Intent.ACTION_VIEW && data != null) openUri(data, false)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        currentSession()?.let {
            outState.putStringArrayList("keys", ArrayList(it.keys))
            outState.putFloat("ratio", it.ratio)
            outState.putIntegerArrayList("pages", ArrayList(it.pages))
        }
    }

    override fun onPause() {
        super.onPause()
        paneA.saveProgress()
        paneB.saveProgress()
        saveSession()
        // nothing is on screen: stop all background rendering and scanning
        handler.removeCallbacks(hideControls)
        paneA.pause()
        paneB.pause()
    }

    override fun onResume() {
        super.onResume()
        paneA.resume()
        paneB.resume()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_BACKGROUND) {
            paneA.trimMemory()
            paneB.trimMemory()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        paneA.release()
        paneB.release()
    }

    // ---------- opening files ----------

    private fun openUri(uri: Uri, asSecond: Boolean) {
        setBusy(true)
        Exec.io.execute {
            try {
                val sig = signatureOf(uri)
                val file = library.cachedFile(sig) ?: run {
                    val name = queryName(uri)
                    contentResolver.openInputStream(uri)!!.use { library.importPdf(it, name) }
                        .also { library.remember(sig, it) }
                }
                runOnUiThread {
                    if (asSecond) {
                        pendingSplit = splitView.right
                        splitView.right.load(file, null)
                    } else {
                        splitView.left.load(file, null)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false)
                    toast("Couldn't open this file")
                }
            }
        }
    }

    /** uri + size + modified time; null when the provider doesn't tell us (then we always copy). */
    private fun signatureOf(uri: Uri): String? {
        return try {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.SIZE, "last_modified"),
                null, null, null
            )?.use { c ->
                if (!c.moveToFirst() || c.isNull(0) || c.isNull(1)) null
                else "${uri}|${c.getLong(0)}|${c.getLong(1)}"
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun queryName(uri: Uri): String {
        var name: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) name = c.getString(0) }
        } catch (_: Exception) {
        }
        val raw = name?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: "document.pdf"
        var s = raw.substringAfterLast('/').replace(Regex("[\\\\:*?\"<>|]"), "_")
        if (!s.lowercase().endsWith(".pdf")) s += ".pdf"
        return s
    }

    private fun openSession(s: Library.Session) {
        val files = s.keys.map { library.fileFor(it) }
        if (files.isEmpty() || files.any { !it.exists() }) {
            toast("That PDF is no longer available")
            updateHome()
            return
        }
        setBusy(true)
        pendingSplit = null
        clearAll()
        if (files.size >= 2) {
            splitView.setSplit(true, s.ratio)
            paneA.load(files[0], s.pages.getOrNull(0))
            paneB.load(files[1], s.pages.getOrNull(1))
        } else {
            paneA.load(files[0], s.pages.getOrNull(0))
        }
    }

    private fun clearAll() {
        paneA.clear()
        paneB.clear()
        splitView.showOnly(paneA)
    }

    // ---------- recent list / home ----------

    private fun currentSession(): Library.Session? {
        val k1 = primary.key ?: return null
        val keys = mutableListOf(k1)
        var ratio = 0.5f
        if (splitView.split) {
            val k2 = splitView.right.key ?: return null // second PDF still loading
            keys.add(k2)
            ratio = splitView.ratio
        }
        val pages = mutableListOf(primary.pageNow())
        if (splitView.split) pages.add(splitView.right.pageNow())
        return Library.Session(keys, keys.map { library.nameOf(it) }, ratio, pages)
    }

    private fun saveSession(async: Boolean = false) {
        val s = currentSession() ?: return
        if (async) Exec.io.execute { library.saveSession(s) } else library.saveSession(s)
    }

    private fun goHome() {
        setControls(false)
        paneA.saveProgress()
        paneB.saveProgress()
        saveSession()
        pendingSplit = null
        clearAll()
        updateHome()
    }

    private fun updateHome() {
        val show = !primary.hasDoc && !busy
        if (show) {
            if (home.visibility != View.VISIBLE) {
                home.animate().cancel()
                home.alpha = 0f
                home.visibility = View.VISIBLE
                home.animate().alpha(1f).setDuration(180).start()
            }
        } else if (home.visibility == View.VISIBLE) {
            home.animate().cancel()
            home.animate().alpha(0f).setDuration(120).withEndAction { home.visibility = View.GONE }.start()
        }
        backCallback.isEnabled = primary.hasDoc
        if (show) buildRecents()
    }

    private fun buildRecents() {
        recentList.removeAllViews()
        val list = library.sessions()
        recentTitle.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        for (s in list) addRow(s)
    }

    private fun addRow(s: Library.Session) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setBackgroundResource(R.drawable.row_bg)
        row.setPadding(dp(16), dp(14), dp(16), dp(14))
        row.isClickable = true
        val tv = TypedValue()
        if (theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) {
            row.foreground = ContextCompat.getDrawable(this, tv.resourceId)
        }

        val title = TextView(this)
        title.text = s.names.joinToString("   +   ")
        title.textSize = 16f
        title.maxLines = 2
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        title.setTypeface(null, Typeface.BOLD)
        row.addView(title)

        val sub = TextView(this)
        sub.text = if (s.keys.size > 1) "Split view \u00B7 ${s.keys.size} PDFs" else "PDF"
        sub.textSize = 12f
        sub.alpha = 0.6f
        row.addView(sub)

        row.setOnClickListener { openSession(s) }

        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(8)
        recentList.addView(row, lp)
    }

    // ---------- split view ----------

    private fun closePane(p: PdfPane) {
        if (!splitView.split) return
        setControls(false)
        val other = if (p === paneA) paneB else paneA
        p.clear()
        splitView.showOnly(other)
        saveSession()
    }

    // ---------- controls & settings ----------

    private fun setControls(on: Boolean) {
        handler.removeCallbacks(hideControls)
        if (on && !primary.hasDoc) return
        controlsOn = on
        splitBtn.visibility = if (splitView.split) View.GONE else View.VISIBLE
        controls.fadeTo(on)
        paneA.showControls(on, splitView.split)
        paneB.showControls(on, splitView.split)
        if (on) handler.postDelayed(hideControls, 3000)
    }

    private fun applyOrientation() {
        requestedOrientation = when (settings.getString("orientation", "auto")) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun showSettings() {
        val values = arrayOf("auto", "portrait", "landscape")
        val labels = arrayOf("Auto-rotate", "Portrait", "Landscape")
        val current = values.indexOf(settings.getString("orientation", "auto")).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Settings: screen orientation")
            .setSingleChoiceItems(labels, current) { dialog, which ->
                settings.edit().putString("orientation", values[which]).apply()
                applyOrientation()
                dialog.dismiss()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private val showProgress = Runnable { if (busy) progress.visibility = View.VISIBLE }

    private fun setBusy(b: Boolean) {
        busy = b
        handler.removeCallbacks(showProgress)
        if (b) handler.postDelayed(showProgress, 250) else progress.visibility = View.GONE
        updateHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
