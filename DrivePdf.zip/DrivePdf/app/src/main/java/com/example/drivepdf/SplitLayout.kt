package com.example.drivepdf

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import com.google.android.material.color.MaterialColors
import kotlin.math.abs

/**
 * Holds two PdfPanes with a draggable divider.
 * Landscape: side by side (left | right). Portrait: stacked (top / bottom).
 * "left" and "right" below mean the first (left or top) and second (right or bottom) pane.
 * ratio = share of the space given to the first pane (0.05 .. 0.95).
 * When one PDF is nearly full size, the other is a thin strip at the end (right or bottom);
 * tapping that strip swaps them, so one tap target always does the switch.
 */
class SplitLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ViewGroup(context, attrs) {

    private lateinit var first: PdfPane
    private lateinit var second: PdfPane

    lateinit var left: PdfPane
        private set
    lateinit var right: PdfPane
        private set

    private val line = LineView(context)
    private val handle = HandleView(context)
    private val scrimRight = View(context)
    private val density = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    var split = false
        private set
    var ratio = 0.5f
        private set

    /** true in portrait: PDFs are stacked top / bottom instead of side by side */
    private var stacked = false

    private var downPos = 0f
    private var dragging = false
    private var animator: ValueAnimator? = null

    private val collapsedRight: Boolean get() = split && ratio > 0.9f

    override fun onFinishInflate() {
        super.onFinishInflate()
        first = getChildAt(0) as PdfPane
        second = getChildAt(1) as PdfPane
        left = first
        right = second
        right.visibility = View.GONE

        scrimRight.setBackgroundColor(context.getColor(R.color.scrim))
        scrimRight.visibility = View.GONE
        line.visibility = View.GONE
        handle.visibility = View.GONE
        scrimRight.setOnClickListener { swapSides() }
        addView(scrimRight)
        addView(line)
        addView(handle)

        val dragListener = View.OnTouchListener { _, e ->
            val pos = if (stacked) e.rawY else e.rawX
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    animator?.cancel()
                    downPos = pos
                    dragging = false
                    parent.requestDisallowInterceptTouchEvent(true)
                    setGrabbed(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && abs(pos - downPos) > slop) dragging = true
                    if (dragging) {
                        val loc = IntArray(2)
                        getLocationOnScreen(loc)
                        if (stacked) setRatio((e.rawY - loc[1]) / height)
                        else setRatio((e.rawX - loc[0]) / width)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    setGrabbed(false)
                    if (!dragging) {
                        if (collapsedRight) swapSides()
                    } else {
                        settle()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    setGrabbed(false)
                    settle()
                }
            }
            true
        }
        line.setOnTouchListener(dragListener)
        handle.setOnTouchListener(dragListener)
    }

    private fun setGrabbed(g: Boolean) {
        line.grabbed = g
        handle.setGrabbed(g)
    }

    /** Show only this pane, full screen. */
    fun showOnly(p: PdfPane) {
        animator?.cancel()
        left = p
        right = if (p === first) second else first
        split = false
        ratio = 0.5f
        left.visibility = View.VISIBLE
        right.visibility = View.GONE
        line.visibility = View.GONE
        handle.visibility = View.GONE
        updateCollapsedState()
        requestLayout()
    }

    fun setSplit(on: Boolean, newRatio: Float = 0.5f) {
        animator?.cancel()
        split = on
        ratio = if (on) newRatio.coerceIn(0.05f, 0.95f) else 0.5f
        val v = if (on) View.VISIBLE else View.GONE
        right.visibility = v
        line.visibility = v
        handle.visibility = v
        updateCollapsedState()
        requestLayout()
    }

    private fun swapSides() {
        val t = left
        left = right
        right = t
        updateCollapsedState()
        requestLayout()
    }

    private fun setRatio(r: Float) {
        ratio = r.coerceIn(0.05f, 0.95f)
        updateCollapsedState()
        requestLayout()
    }

    /** Dragged far enough -> one PDF takes 95%, the other is a 5% strip at the end. */
    private fun settle() {
        when {
            ratio > 0.8f -> animateTo(0.95f)
            ratio < 0.2f -> {
                animator?.cancel()
                swapSides()
                setRatio(0.95f)
            }
        }
    }

    private fun animateTo(target: Float) {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(ratio, target).apply {
            duration = 180
            addUpdateListener { setRatio(it.animatedValue as Float) }
            start()
        }
    }

    private fun updateCollapsedState() {
        scrimRight.visibility = if (collapsedRight) View.VISIBLE else View.GONE
        left.setCollapsed(split && ratio < 0.1f)
        right.setCollapsed(collapsedRight)
        // keep the first pane's fast-scroll handle out from under the divider
        val pad = (14 * density).toInt()
        left.setScrollerInsets(
            if (split && !stacked) pad else 0,
            if (split && stacked) pad else 0
        )
        right.setScrollerInsets(0, 0)
    }

    private fun applyOrientation() {
        line.horizontal = stacked
        handle.horizontal = stacked
        updateCollapsedState()
    }

    private fun sizeFirst(total: Int) = if (split) (total * ratio).toInt() else total

    private fun exactly(px: Int) = MeasureSpec.makeMeasureSpec(px, MeasureSpec.EXACTLY)

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        setMeasuredDimension(w, h)

        val nowStacked = h > w
        if (nowStacked != stacked) {
            stacked = nowStacked
            applyOrientation()
        }

        val line20 = (20 * density).toInt()
        val handleShort = (18 * density).toInt()
        val handleLong = (60 * density).toInt()
        if (stacked) {
            val fh = sizeFirst(h)
            left.measure(exactly(w), exactly(fh))
            if (split) {
                right.measure(exactly(w), exactly(h - fh))
                scrimRight.measure(exactly(w), exactly(h - fh))
                line.measure(exactly(w), exactly(line20))
                handle.measure(exactly(handleLong), exactly(handleShort))
            }
        } else {
            val fw = sizeFirst(w)
            left.measure(exactly(fw), exactly(h))
            if (split) {
                right.measure(exactly(w - fw), exactly(h))
                scrimRight.measure(exactly(w - fw), exactly(h))
                line.measure(exactly(line20), exactly(h))
                handle.measure(exactly(handleShort), exactly(handleLong))
            }
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        val lineHalf = (10 * density).toInt()
        val hShort = (9 * density).toInt()
        val hLong = (30 * density).toInt()
        if (stacked) {
            val fh = sizeFirst(h)
            left.layout(0, 0, w, fh)
            if (split) {
                right.layout(0, fh, w, h)
                scrimRight.layout(0, fh, w, h)
                line.layout(0, fh - lineHalf, w, fh + lineHalf)
                handle.layout(w / 2 - hLong, fh - hShort, w / 2 + hLong, fh + hShort)
            }
        } else {
            val fw = sizeFirst(w)
            left.layout(0, 0, fw, h)
            if (split) {
                right.layout(fw, 0, w, h)
                scrimRight.layout(fw, 0, w, h)
                line.layout(fw - lineHalf, 0, fw + lineHalf, h)
                handle.layout(fw - hShort, h / 2 - hLong, fw + hShort, h / 2 + hLong)
            }
        }
    }

    /** The thin line: a crisp 1.5dp rule with a soft shadow on both sides. */
    private class LineView(context: Context) : View(context) {
        private val d = resources.displayMetrics.density
        private val idle = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorOutline, 0xFF9AA0A6.toInt()
        )
        private val active = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorPrimary, Color.BLUE
        )
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val shadowBefore = Paint()
        private val shadowAfter = Paint()

        var grabbed = false
            set(v) {
                field = v
                invalidate()
            }

        var horizontal = false
            set(v) {
                field = v
                rebuild()
                invalidate()
            }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            rebuild()
        }

        private fun rebuild() {
            if (width == 0 || height == 0) return
            val s = 8 * d
            if (horizontal) {
                val cy = height / 2f
                shadowBefore.shader = LinearGradient(
                    0f, cy - s, 0f, cy, 0x00000000, 0x22000000, Shader.TileMode.CLAMP
                )
                shadowAfter.shader = LinearGradient(
                    0f, cy, 0f, cy + s, 0x22000000, 0x00000000, Shader.TileMode.CLAMP
                )
            } else {
                val cx = width / 2f
                shadowBefore.shader = LinearGradient(
                    cx - s, 0f, cx, 0f, 0x00000000, 0x22000000, Shader.TileMode.CLAMP
                )
                shadowAfter.shader = LinearGradient(
                    cx, 0f, cx + s, 0f, 0x22000000, 0x00000000, Shader.TileMode.CLAMP
                )
            }
        }

        override fun onDraw(canvas: Canvas) {
            val s = 8 * d
            val half = (if (grabbed) 1.5f else 0.75f) * d
            linePaint.color = if (grabbed) active else idle
            if (horizontal) {
                val cy = height / 2f
                canvas.drawRect(0f, cy - s, width.toFloat(), cy, shadowBefore)
                canvas.drawRect(0f, cy, width.toFloat(), cy + s, shadowAfter)
                canvas.drawRect(0f, cy - half, width.toFloat(), cy + half, linePaint)
            } else {
                val cx = width / 2f
                canvas.drawRect(cx - s, 0f, cx, height.toFloat(), shadowBefore)
                canvas.drawRect(cx, 0f, cx + s, height.toFloat(), shadowAfter)
                canvas.drawRect(cx - half, 0f, cx + half, height.toFloat(), linePaint)
            }
        }
    }

    /** The grab handle: a floating rounded pill with grip dots; turns blue and grows while dragged. */
    private class HandleView(context: Context) : View(context) {
        private val d = resources.displayMetrics.density
        private val surface = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorSurface, Color.WHITE
        )
        private val outline = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorOutline, Color.GRAY
        )
        private val primary = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorPrimary, Color.BLUE
        )
        private val onPrimary = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorOnPrimary, Color.WHITE
        )
        private val gripIdle = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY
        )
        private val strokePx = (1 * d).toInt().coerceAtLeast(1)
        private val bg = GradientDrawable().apply {
            cornerRadius = 9 * d
            setColor(surface)
            setStroke(strokePx, outline)
        }
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = gripIdle }

        var horizontal = false
            set(v) {
                field = v
                invalidate()
            }

        init {
            background = bg
            elevation = 6 * d
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }

        fun setGrabbed(g: Boolean) {
            bg.setColor(if (g) primary else surface)
            bg.setStroke(strokePx, if (g) primary else outline)
            dotPaint.color = if (g) onPrimary else gripIdle
            animate().cancel()
            animate().scaleX(if (g) 1.15f else 1f).scaleY(if (g) 1.15f else 1f).setDuration(120).start()
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val r = 1.4f * d
            val gap = 7 * d
            val col = 3 * d
            for (i in -1..1) {
                if (horizontal) {
                    canvas.drawCircle(cx + i * gap, cy - col, r, dotPaint)
                    canvas.drawCircle(cx + i * gap, cy + col, r, dotPaint)
                } else {
                    canvas.drawCircle(cx - col, cy + i * gap, r, dotPaint)
                    canvas.drawCircle(cx + col, cy + i * gap, r, dotPaint)
                }
            }
        }
    }
}
