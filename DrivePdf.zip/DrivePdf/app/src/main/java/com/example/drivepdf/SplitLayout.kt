package com.example.drivepdf

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import kotlin.math.abs

/**
 * Holds two PdfPanes side by side with a draggable divider.
 * ratio = share of the width given to the left pane (0.05 .. 0.95).
 */
class SplitLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ViewGroup(context, attrs) {

    private lateinit var paneA: PdfPane
    private lateinit var paneB: PdfPane
    private val divider = DividerView(context)
    private val scrimA = View(context)
    private val scrimB = View(context)
    private val density = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    var split = false
        private set
    var ratio = 0.5f
        private set

    private var downX = 0f
    private var dragging = false
    private var animator: ValueAnimator? = null

    private val collapsedA: Boolean get() = split && ratio < 0.1f
    private val collapsedB: Boolean get() = split && ratio > 0.9f

    override fun onFinishInflate() {
        super.onFinishInflate()
        paneA = getChildAt(0) as PdfPane
        paneB = getChildAt(1) as PdfPane
        paneB.visibility = View.GONE

        val scrim = context.getColor(R.color.scrim)
        scrimA.setBackgroundColor(scrim)
        scrimB.setBackgroundColor(scrim)
        scrimA.visibility = View.GONE
        scrimB.visibility = View.GONE
        divider.visibility = View.GONE
        // tapping the thin strip of the collapsed PDF brings it back to 95%
        scrimA.setOnClickListener { animateTo(0.95f) }
        scrimB.setOnClickListener { animateTo(0.05f) }
        addView(scrimA)
        addView(scrimB)
        addView(divider)

        divider.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    animator?.cancel()
                    downX = e.rawX
                    dragging = false
                    parent.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && abs(e.rawX - downX) > slop) dragging = true
                    if (dragging) {
                        val loc = IntArray(2)
                        getLocationOnScreen(loc)
                        setRatio((e.rawX - loc[0]) / width)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        if (collapsedA) animateTo(0.95f) else if (collapsedB) animateTo(0.05f)
                    } else {
                        settle()
                    }
                }
                MotionEvent.ACTION_CANCEL -> settle()
            }
            true
        }
    }

    fun setSplit(on: Boolean, newRatio: Float = 0.5f) {
        animator?.cancel()
        split = on
        ratio = if (on) newRatio.coerceIn(0.05f, 0.95f) else 0.5f
        val v = if (on) View.VISIBLE else View.GONE
        paneB.visibility = v
        divider.visibility = v
        updateCollapsedState()
        requestLayout()
    }

    private fun setRatio(r: Float) {
        ratio = r.coerceIn(0.05f, 0.95f)
        updateCollapsedState()
        requestLayout()
    }

    /** Dragged far enough -> snap one PDF to 95% and the other to 5%. */
    private fun settle() {
        val target = when {
            ratio > 0.8f -> 0.95f
            ratio < 0.2f -> 0.05f
            else -> ratio
        }
        if (target != ratio) animateTo(target)
    }

    private fun animateTo(target: Float) {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(ratio, target).apply {
            duration = 180
            addUpdateListener { setRatio(it.animatedValue as Float) }
            start()
        }
    }

    private fun updateCollapsedState() {
        scrimA.visibility = if (collapsedA) View.VISIBLE else View.GONE
        scrimB.visibility = if (collapsedB) View.VISIBLE else View.GONE
        paneA.setCollapsed(collapsedA)
        paneB.setCollapsed(collapsedB)
    }

    private fun widthA(w: Int) = if (split) (w * ratio).toInt() else w

    private fun exactly(px: Int) = MeasureSpec.makeMeasureSpec(px, MeasureSpec.EXACTLY)

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        setMeasuredDimension(w, h)
        val aw = widthA(w)
        paneA.measure(exactly(aw), exactly(h))
        if (split) {
            val bw = w - aw
            paneB.measure(exactly(bw), exactly(h))
            scrimA.measure(exactly(aw), exactly(h))
            scrimB.measure(exactly(bw), exactly(h))
            divider.measure(exactly((24 * density).toInt()), exactly(h))
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        val aw = widthA(w)
        paneA.layout(0, 0, aw, h)
        if (split) {
            paneB.layout(aw, 0, w, h)
            scrimA.layout(0, 0, aw, h)
            scrimB.layout(aw, 0, w, h)
            val half = (12 * density).toInt()
            divider.layout(aw - half, 0, aw + half, h)
        }
    }

    private class DividerView(context: Context) : View(context) {
        private val line = Paint().apply { color = 0xFF9AA0A6.toInt() }
        private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5F6368.toInt() }

        override fun onDraw(canvas: Canvas) {
            val d = resources.displayMetrics.density
            val cx = width / 2f
            canvas.drawRect(cx - d, 0f, cx + d, height.toFloat(), line)
            val hw = 6 * d
            val hh = 28 * d
            canvas.drawRoundRect(cx - hw, height / 2f - hh, cx + hw, height / 2f + hh, hw, hw, handle)
        }
    }
}
