package com.example.drivepdf

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import com.google.android.material.color.MaterialColors
import kotlin.math.abs

/**
 * Holds two PdfPanes with a draggable divider.
 * Landscape: side by side (left | right). Portrait: stacked (top / bottom).
 * "left" and "right" below mean the first (left or top) and second (right or bottom) pane.
 * ratio = share of the space given to the first pane (0.05 .. 0.95).
 * When one PDF is nearly full size, the other is a thin strip at the end (right or bottom);
 * tapping that strip swaps them, so one tap target always does the switch.
 */
class SplitLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ViewGroup(context, attrs) {

    private lateinit var first: PdfPane
    private lateinit var second: PdfPane

    lateinit var left: PdfPane
        private set
    lateinit var right: PdfPane
        private set

    private val line = LineView(context)
    private val handle = HandleView(context)
    private val scrimRight = View(context)
    private val density = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    var split = false
        private set
    var ratio = 0.5f
        private set

    /** true in portrait: PDFs are stacked top / bottom instead of side by side */
    private var stacked = false

    private var downPos = 0f
    private var dragging = false
    private var animator: ValueAnimator? = null

    private val collapsedRight: Boolean get() = split && !calcMode && ratio > 0.9f

    // ---------- calculator in the second slot ----------
    private lateinit var calc: CalculatorView
    var calcMode = false
        private set
    private var calcAnimating = false
    private var calcExiting = false
    private var savedSplit = false
    private var savedRatio = 0.5f

    /** pdf share of the space the calculator layout used last time (per orientation) */
    var calcRatioFor: ((stacked: Boolean) -> Float)? = null
    var onCalcRatioChanged: ((stacked: Boolean, ratio: Float) -> Unit)? = null

    /** true only when two PDFs are shown (not when the calculator takes the second slot) */
    val twoPdfs: Boolean get() = split && !calcMode

    /** what to remember for the "recent" session, ignoring the temporary calculator */
    val sessionSplit: Boolean get() = if (calcMode) savedSplit else split
    val sessionRatio: Float get() = if (calcMode) savedRatio else ratio

    private val secondSlot: View get() = if (calcMode) calc else right

    fun enterCalc() {
        if (calcMode) return
        animator?.cancel()
        savedSplit = split
        savedRatio = ratio
        calcMode = true
        calcExiting = false
        split = true
        right.visibility = View.GONE
        calc.visibility = View.VISIBLE
        line.visibility = View.VISIBLE
        handle.visibility = View.VISIBLE
        val target = (calcRatioFor?.invoke(stacked) ?: if (stacked) 0.5f else 0.62f).coerceIn(0.2f, 0.8f)
        calcAnimating = true
        ratio = 0.97f
        updateCollapsedState()
        requestLayout()
        animator = ValueAnimator.ofFloat(0.97f, target).apply {
            duration = 280
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener {
                ratio = it.animatedValue as Float
                requestLayout()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    calcAnimating = false
                }
            })
            start()
        }
    }

    fun exitCalc() {
        if (!calcMode || calcExiting) return
        animator?.cancel()
        calcExiting = true
        calcAnimating = true
        saveCalcRatio()
        animator = ValueAnimator.ofFloat(ratio, 0.97f).apply {
            duration = 220
            interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener {
                ratio = it.animatedValue as Float
                requestLayout()
            }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(a: Animator) {
                    if (!cancelled) finishExitCalc()
                }
            })
            start()
        }
    }

    private fun finishExitCalc() {
        calcAnimating = false
        calcExiting = false
        calcMode = false
        calc.visibility = View.GONE
        if (savedSplit) setSplit(true, savedRatio) else showOnly(left)
    }

    /** Leave calculator mode instantly (no animation), e.g. when going Home or opening something new. */
    private fun endCalcNow() {
        if (!calcMode) return
        animator?.cancel()
        calcAnimating = false
        calcExiting = false
        calcMode = false
        calc.visibility = View.GONE
    }

    /** Calculator is on and two PDFs are open: a tap on the divider shows the other PDF. */
    private fun swapPdfBesideCalc() {
        if (calcExiting) return
        val shown = left
        val other = right
        shown.animate().cancel()
        other.animate().cancel()
        left = other
        right = shown
        shown.visibility = View.GONE
        other.alpha = 0f
        other.visibility = View.VISIBLE
        updateCollapsedState()
        requestLayout()
        other.animate().alpha(1f).setDuration(160).start()
        handle.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun saveCalcRatio() {
        if (calcMode && ratio <= 0.8f) onCalcRatioChanged?.invoke(stacked, ratio)
    }

    override fun onFinishInflate() {
        super.onFinishInflate()
        first = getChildAt(0) as PdfPane
        second = getChildAt(1) as PdfPane
        left = first
        right = second
        right.visibility = View.GONE

        calc = CalculatorView(context)
        calc.visibility = View.GONE
        addView(calc)

        scrimRight.setBackgroundColor(context.getColor(R.color.scrim))
        scrimRight.visibility = View.GONE
        line.visibility = View.GONE
        handle.visibility = View.GONE
        scrimRight.setOnClickListener { swapSides() }
        addView(scrimRight)
        addView(line)
        addView(handle)

        val dragListener = View.OnTouchListener { _, e ->
            val pos = if (stacked) e.rawY else e.rawX
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    animator?.cancel()
                    calcExiting = false
                    calcAnimating = false
                    downPos = pos
                    dragging = false
                    parent.requestDisallowInterceptTouchEvent(true)
                    setGrabbed(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && abs(pos - downPos) > slop) dragging = true
                    if (dragging) {
                        val loc = IntArray(2)
                        getLocationOnScreen(loc)
                        if (stacked) setRatio((e.rawY - loc[1]) / height)
                        else setRatio((e.rawX - loc[0]) / width)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    setGrabbed(false)
                    if (!dragging) {
                        if (collapsedRight) swapSides()
                        else if (calcMode && savedSplit) swapPdfBesideCalc()
                    } else {
                        settle()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    setGrabbed(false)
                    settle()
                }
            }
            true
        }
        line.setOnTouchListener(dragListener)
        handle.setOnTouchListener(dragListener)
    }

    private fun setGrabbed(g: Boolean) {
        line.grabbed = g
        handle.setGrabbed(g)
    }

    /** Show only this pane, full screen. */
    fun showOnly(p: PdfPane) {
        endCalcNow()
        animator?.cancel()
        left = p
        right = if (p === first) second else first
        split = false
        ratio = 0.5f
        left.visibility = View.VISIBLE
        right.visibility = View.GONE
        line.visibility = View.GONE
        handle.visibility = View.GONE
        updateCollapsedState()
        requestLayout()
    }

    fun setSplit(on: Boolean, newRatio: Float = 0.5f) {
        endCalcNow()
        animator?.cancel()
        split = on
        ratio = if (on) newRatio.coerceIn(0.05f, 0.95f) else 0.5f
        val v = if (on) View.VISIBLE else View.GONE
        right.visibility = v
        line.visibility = v
        handle.visibility = v
        updateCollapsedState()
        requestLayout()
    }

    private fun swapSides() {
        if (calcMode) return
        val t = left
        left = right
        right = t
        updateCollapsedState()
        requestLayout()
    }

    private var lastState = -1

    private fun setRatio(r: Float) {
        val nr = if (calcMode) r.coerceIn(0.2f, 0.8f) else r.coerceIn(0.05f, 0.95f)
        if (nr == ratio) return
        ratio = nr
        // only touch the panes' overlays when something actually changed (cheap per frame)
        val state = (if (collapsedRight) 1 else 0) + (if (split && ratio < 0.1f) 2 else 0)
        if (state != lastState) {
            lastState = state
            updateCollapsedState()
        }
        requestLayout()
    }

    /** Dragged far enough -> one PDF takes 95%, the other is a 5% strip at the end. */
    private fun settle() {
        if (calcMode) {
            saveCalcRatio()
            return
        }
        when {
            ratio > 0.8f -> animateTo(0.95f)
            ratio < 0.2f -> {
                animator?.cancel()
                swapSides()
                setRatio(0.95f)
            }
        }
    }

    private fun animateTo(target: Float) {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(ratio, target).apply {
            duration = 240
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { setRatio(it.animatedValue as Float) }
            start()
        }
    }

    private fun updateCollapsedState() {
        scrimRight.visibility = if (collapsedRight) View.VISIBLE else View.GONE
        left.setCollapsed(split && ratio < 0.1f)
        right.setCollapsed(collapsedRight)
        // keep the first pane's fast-scroll handle out from under the divider
        val pad = (14 * density).toInt()
        left.setScrollerInsets(
            if (split && !stacked) pad else 0,
            if (split && stacked) pad else 0
        )
        right.setScrollerInsets(0, 0)
    }

    private fun applyOrientation() {
        line.horizontal = stacked
        handle.horizontal = stacked
        updateCollapsedState()
    }

    private fun sizeFirst(total: Int): Int {
        if (!split) return total
        var f = (total * ratio).toInt()
        if (calcMode && !calcAnimating) {
            // keep the calculator big enough to use
            val minCalc = ((if (stacked) 280 else 210) * density).toInt()
            f = f.coerceAtMost(maxOf(total - minCalc, total / 5))
        }
        return f
    }

    private fun exactly(px: Int) = MeasureSpec.makeMeasureSpec(px, MeasureSpec.EXACTLY)

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        setMeasuredDimension(w, h)

        val nowStacked = h > w
        if (nowStacked != stacked) {
            stacked = nowStacked
            applyOrientation()
            if (calcMode && !calcAnimating) {
                ratio = (calcRatioFor?.invoke(stacked) ?: ratio).coerceIn(0.2f, 0.8f)
            }
        }

        val line20 = (20 * density).toInt()
        val handleShort = (16 * density).toInt()
        val handleLong = (56 * density).toInt()
        if (stacked) {
            val fh = sizeFirst(h)
            left.measure(exactly(w), exactly(fh))
            if (split) {
                secondSlot.measure(exactly(w), exactly(h - fh))
                scrimRight.measure(exactly(w), exactly(h - fh))
                line.measure(exactly(w), exactly(line20))
                handle.measure(exactly(handleLong), exactly(handleShort))
            }
        } else {
            val fw = sizeFirst(w)
            left.measure(exactly(fw), exactly(h))
            if (split) {
                secondSlot.measure(exactly(w - fw), exactly(h))
                scrimRight.measure(exactly(w - fw), exactly(h))
                line.measure(exactly(line20), exactly(h))
                handle.measure(exactly(handleShort), exactly(handleLong))
            }
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        val lineHalf = (10 * density).toInt()
        val hShort = (8 * density).toInt()
        val hLong = (28 * density).toInt()
        if (stacked) {
            val fh = sizeFirst(h)
            left.layout(0, 0, w, fh)
            if (split) {
                secondSlot.layout(0, fh, w, h)
                scrimRight.layout(0, fh, w, h)
                line.layout(0, fh - lineHalf, w, fh + lineHalf)
                handle.layout(w / 2 - hLong, fh - hShort, w / 2 + hLong, fh + hShort)
            }
        } else {
            val fw = sizeFirst(w)
            left.layout(0, 0, fw, h)
            if (split) {
                secondSlot.layout(fw, 0, w, h)
                scrimRight.layout(fw, 0, w, h)
                line.layout(fw - lineHalf, 0, fw + lineHalf, h)
                handle.layout(fw - hShort, h / 2 - hLong, fw + hShort, h / 2 + hLong)
            }
        }
    }

    /** The thin line: a crisp 1.5dp rule with a soft shadow on both sides. */
    private class LineView(context: Context) : View(context) {
        private val d = resources.displayMetrics.density
        private val idle = (MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorOutline, 0xFF9AA0A6.toInt()
        ) and 0x00FFFFFF) or (0x99 shl 24)
        private val active = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorPrimary, Color.BLUE
        )
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val shadowBefore = Paint()
        private val shadowAfter = Paint()

        var grabbed = false
            set(v) {
                field = v
                invalidate()
            }

        var horizontal = false
            set(v) {
                field = v
                rebuild()
                invalidate()
            }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            rebuild()
        }

        private fun rebuild() {
            if (width == 0 || height == 0) return
            val s = 6 * d
            if (horizontal) {
                val cy = height / 2f
                shadowBefore.shader = LinearGradient(
                    0f, cy - s, 0f, cy, 0x00000000, 0x1A000000, Shader.TileMode.CLAMP
                )
                shadowAfter.shader = LinearGradient(
                    0f, cy, 0f, cy + s, 0x1A000000, 0x00000000, Shader.TileMode.CLAMP
                )
            } else {
                val cx = width / 2f
                shadowBefore.shader = LinearGradient(
                    cx - s, 0f, cx, 0f, 0x00000000, 0x1A000000, Shader.TileMode.CLAMP
                )
                shadowAfter.shader = LinearGradient(
                    cx, 0f, cx + s, 0f, 0x1A000000, 0x00000000, Shader.TileMode.CLAMP
                )
            }
        }

        override fun onDraw(canvas: Canvas) {
            val s = 6 * d
            val half = (if (grabbed) 1.25f else 0.5f) * d
            linePaint.color = if (grabbed) active else idle
            if (horizontal) {
                val cy = height / 2f
                canvas.drawRect(0f, cy - s, width.toFloat(), cy, shadowBefore)
                canvas.drawRect(0f, cy, width.toFloat(), cy + s, shadowAfter)
                canvas.drawRect(0f, cy - half, width.toFloat(), cy + half, linePaint)
            } else {
                val cx = width / 2f
                canvas.drawRect(cx - s, 0f, cx, height.toFloat(), shadowBefore)
                canvas.drawRect(cx, 0f, cx + s, height.toFloat(), shadowAfter)
                canvas.drawRect(cx - half, 0f, cx + half, height.toFloat(), linePaint)
            }
        }
    }

    /** The grab handle: a floating rounded pill with grip dots; turns blue and grows while dragged. */
    private class HandleView(context: Context) : View(context) {
        private val d = resources.displayMetrics.density
        private val surface = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorSurface, Color.WHITE
        )
        private val outline = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorOutline, Color.GRAY
        )
        private val primary = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorPrimary, Color.BLUE
        )
        private val onPrimary = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorOnPrimary, Color.WHITE
        )
        private val gripIdle = MaterialColors.getColor(
            context, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY
        )
        private val strokePx = (1 * d).toInt().coerceAtLeast(1)
        private val bg = GradientDrawable().apply {
            cornerRadius = 100 * d
            setColor(surface)
            setStroke(strokePx, (outline and 0x00FFFFFF) or (0x80 shl 24))
        }
        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = gripIdle }

        var horizontal = false
            set(v) {
                field = v
                invalidate()
            }

        init {
            background = bg
            elevation = 4 * d
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }

        fun setGrabbed(g: Boolean) {
            bg.setColor(if (g) primary else surface)
            bg.setStroke(strokePx, if (g) primary else (outline and 0x00FFFFFF) or (0x80 shl 24))
            barPaint.color = if (g) onPrimary else gripIdle
            animate().cancel()
            animate().scaleX(if (g) 1.2f else 1f).scaleY(if (g) 1.2f else 1f)
                .setDuration(140).setInterpolator(DecelerateInterpolator()).start()
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val half = 14 * d // half length of the grip bar
            val t = 1.5f * d // half thickness
            if (horizontal) {
                canvas.drawRoundRect(cx - half, cy - t, cx + half, cy + t, t, t, barPaint)
            } else {
                canvas.drawRoundRect(cx - t, cy - half, cx + t, cy + half, t, t, barPaint)
            }
        }
    }
}
