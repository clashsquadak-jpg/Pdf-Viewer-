package com.example.drivepdf

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.util.AttributeSet
import android.util.SparseArray
import android.view.LayoutInflater
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.view.doOnLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors

/** One PDF view: pages, zoom, page indicator, remembers the last page. */
class PdfPane @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private lateinit var recycler: ZoomRecyclerView
    private lateinit var pill: TextView
    private lateinit var closeBtn: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val renderExec = Executors.newSingleThreadExecutor()
    private val prefs = context.getSharedPreferences("pdf_positions", Context.MODE_PRIVATE)
    private val hidePill = Runnable { pill.animate().alpha(0f).setDuration(300).start() }

    private var doc: PdfDoc? = null
    private var key: String? = null
    private var collapsed = false
    private var released = false

    @Volatile
    var file: File? = null
        private set

    var onTap: (() -> Unit)? = null
    var onClose: (() -> Unit)? = null
    var onLoaded: (() -> Unit)? = null
    var onFailed: ((String) -> Unit)? = null

    val hasDoc: Boolean get() = doc != null

    private val readapt = Runnable {
        val ad = recycler.adapter as? PageAdapter ?: return@Runnable
        val w = recycler.width
        if (w > dp(80) && w != ad.itemWidth) {
            val lm = recycler.layoutManager as LinearLayoutManager
            val pos = lm.findFirstVisibleItemPosition().coerceAtLeast(0)
            ad.setItemWidth(w)
            lm.scrollToPositionWithOffset(pos, 0)
        }
    }

    init {
        LayoutInflater.from(context).inflate(R.layout.view_pane, this, true)
        recycler = findViewById(R.id.recycler)
        pill = findViewById(R.id.pill)
        closeBtn = findViewById(R.id.closeBtn)

        recycler.layoutManager = LinearLayoutManager(context)
        recycler.itemAnimator = null
        recycler.onTap = { onTap?.invoke() }
        recycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (doc != null && dy != 0) {
                    updatePill()
                    showPill()
                }
            }
        })
        closeBtn.setOnClickListener { onClose?.invoke() }
    }

    // Two panes share the same view ids, so don't let Android mix up their saved states.
    override fun dispatchSaveInstanceState(container: SparseArray<Parcelable>) {}
    override fun dispatchRestoreInstanceState(container: SparseArray<Parcelable>) {}

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w != oldw) {
            handler.removeCallbacks(readapt)
            handler.postDelayed(readapt, 250)
        }
    }

    // ---------- loading ----------

    /** page == null means: use the page saved last time for this PDF. */
    fun load(f: File, page: Int?) {
        Exec.io.execute {
            try {
                val d = PdfDoc(f)
                if (d.pageCount == 0) {
                    d.close()
                    fail("This PDF has no pages")
                    return@execute
                }
                val k = keyFor(f)
                val start = page ?: prefs.getInt(k, 0)
                handler.post { show(d, f, k, start) }
            } catch (e: SecurityException) {
                fail("Password-protected PDFs aren't supported")
            } catch (e: Exception) {
                fail("Couldn't open this PDF")
            }
        }
    }

    private fun fail(msg: String) {
        handler.post { onFailed?.invoke(msg) }
    }

    private fun show(d: PdfDoc, f: File, k: String, page: Int) {
        if (released) {
            d.close()
            return
        }
        saveProgress()
        doc?.let { old ->
            recycler.adapter = null
            old.close()
        }
        doc = d
        file = f
        key = k
        recycler.resetZoom()
        recycler.doOnLayout {
            if (doc === d && !released) {
                recycler.adapter = PageAdapter(d, recycler.width, dp(8), dp(4), renderExec)
                (recycler.layoutManager as LinearLayoutManager)
                    .scrollToPositionWithOffset(page.coerceIn(0, d.pageCount - 1), 0)
                updatePill()
                showPill()
            }
        }
        onLoaded?.invoke()
    }

    /** Close the PDF in this pane (the pane itself stays usable). */
    fun clear() {
        saveProgress()
        handler.removeCallbacks(readapt)
        recycler.adapter = null
        doc?.close()
        doc = null
        file = null
        key = null
        pill.alpha = 0f
        closeBtn.visibility = GONE
    }

    fun release() {
        released = true
        handler.removeCallbacksAndMessages(null)
        doc?.close()
        doc = null
        renderExec.shutdownNow()
    }

    // ---------- remembering the last page ----------

    /** Same PDF = same size + same first 256 KB, so renaming or re-opening keeps its page. */
    private fun keyFor(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(f.length().toString().toByteArray())
        f.inputStream().use { input ->
            val buf = ByteArray(256 * 1024)
            val n = input.read(buf)
            if (n > 0) md.update(buf, 0, n)
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun saveProgress() {
        val k = key ?: return
        if (doc == null || recycler.adapter == null) return
        val lm = recycler.layoutManager as LinearLayoutManager
        if (lm.findFirstVisibleItemPosition() < 0) return
        prefs.edit().putInt(k, currentPage()).apply()
    }

    fun currentPage(): Int {
        val d = doc ?: return 0
        val lm = recycler.layoutManager as LinearLayoutManager
        var p = lm.findFirstVisibleItemPosition()
        if (p < 0) return 0
        val v = lm.findViewByPosition(p)
        if (v != null && v.bottom < recycler.visibleHeight * 0.4f && p < d.pageCount - 1) p++
        return p
    }

    // ---------- overlay ----------

    private fun updatePill() {
        val d = doc ?: return
        pill.text = "${currentPage() + 1} / ${d.pageCount}"
    }

    private fun showPill() {
        if (collapsed) return
        handler.removeCallbacks(hidePill)
        pill.animate().alpha(1f).setDuration(100).start()
        handler.postDelayed(hidePill, 1500)
    }

    fun setCollapsed(c: Boolean) {
        collapsed = c
        if (c) {
            closeBtn.visibility = GONE
            pill.alpha = 0f
        }
    }

    /** Show or hide the overlay (page number + Close button in split view). */
    fun showControls(show: Boolean, closable: Boolean) {
        handler.removeCallbacks(hidePill)
        closeBtn.fadeTo(show && closable && !collapsed)
        if (show && doc != null && !collapsed) {
            updatePill()
            pill.animate().alpha(1f).setDuration(100).start()
        } else {
            pill.animate().alpha(0f).setDuration(300).start()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
