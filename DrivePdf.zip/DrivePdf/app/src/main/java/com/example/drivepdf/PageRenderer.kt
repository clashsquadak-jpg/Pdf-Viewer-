package com.example.drivepdf

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.math.abs

/**
 * Renders pages on one background thread. Always renders the page nearest to what is on
 * screen first, and drops requests for pages the user has already scrolled far away from.
 */
class PageRenderer(
    private val doc: PdfDoc,
    private val deliver: (Int, Bitmap) -> Unit
) {
    private val lock = ReentrantLock()
    private val cond = lock.newCondition()
    private val wanted = HashMap<Int, Int>() // page -> requested width in px
    private var focus = 0
    private var lo = 0
    private var hi = Int.MAX_VALUE
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var stopped = false

    private val thread = Thread({ loop() }, "pdf-render").apply {
        isDaemon = true
        start()
    }

    fun request(pos: Int, width: Int) {
        lock.withLock {
            val old = wanted[pos]
            if (old == null || old < width) wanted[pos] = width
            cond.signalAll()
        }
    }

    fun setWindow(first: Int, last: Int) {
        lock.withLock {
            lo = first - 2
            hi = last + 3
            focus = (first + last) / 2
            wanted.keys.removeAll { it < lo || it > hi }
        }
    }

    fun stop() {
        stopped = true
        lock.withLock { cond.signalAll() }
    }

    private fun loop() {
        while (!stopped) {
            var pos = -1
            var width = 0
            lock.withLock {
                while (wanted.isEmpty() && !stopped) cond.await()
                if (stopped) return
                var best = -1
                var bestD = Int.MAX_VALUE
                for (p in wanted.keys) {
                    val d = abs(p - focus) * 2 + (if (p < focus) 1 else 0)
                    if (d < bestD) {
                        bestD = d
                        best = p
                    }
                }
                pos = best
                width = wanted.remove(best) ?: 0
            }
            try {
                val bmp = doc.render(pos, width)
                main.post { if (!stopped) deliver(pos, bmp) }
            } catch (e: OutOfMemoryError) {
                // skip this page, try the next one
            } catch (e: Exception) {
                // document closed or page unreadable
            }
        }
    }
}
