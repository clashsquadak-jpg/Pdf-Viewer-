package com.example.drivepdf

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.math.abs

/**
 * Renders pages on one background thread. Always renders the page nearest to what is on
 * screen first, and drops requests for pages the user has already scrolled far away from.
 */
class PageRenderer(
    private val doc: PdfDoc,
    private val deliver: (Int, Bitmap) -> Unit
) {
    private val lock = ReentrantLock()
    private val cond = lock.newCondition()
    private val wanted = HashMap<Int, Int>() // page -> requested width in px
    private val quick = HashMap<Int, Int>() // page -> low-res preview width (rendered before any full page)
    private var focus = 0
    private var lo = 0
    private var hi = Int.MAX_VALUE
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var stopped = false
    private var paused = false

    private val thread = Thread({ loop() }, "pdf-render").apply {
        isDaemon = true
        start()
    }

    fun request(pos: Int, width: Int, preview: Boolean = false) {
        lock.withLock {
            if (paused) return
            if (preview) {
                // previews are only for pages the user is about to see; others go straight to full
                if (abs(pos - focus) > 2) return
                if (!quick.containsKey(pos)) quick[pos] = width
                cond.signalAll()
                return
            }
            val old = wanted[pos]
            if (old == null || old < width) wanted[pos] = width
            cond.signalAll()
        }
    }

    fun setWindow(first: Int, last: Int) {
        lock.withLock {
            lo = first - 6
            hi = last + 8
            focus = (first + last) / 2
            wanted.keys.removeAll { it < lo || it > hi }
            quick.keys.removeAll { it < lo || it > hi }
        }
    }

    /** App went to the background: forget queued work and sleep (no CPU, no battery). */
    fun pause() {
        lock.withLock {
            paused = true
            wanted.clear()
            quick.clear()
        }
    }

    fun resume() {
        lock.withLock { paused = false }
    }

    fun stop() {
        stopped = true
        lock.withLock { cond.signalAll() }
    }

    private fun loop() {
        while (!stopped) {
            var pos = -1
            var width = 0
            lock.withLock {
                while ((paused || (wanted.isEmpty() && quick.isEmpty())) && !stopped) cond.await()
                if (stopped) return
                // previews are cheap, so they go first: something shows up almost instantly
                val src = if (quick.isNotEmpty()) quick else wanted
                var best = -1
                var bestD = Int.MAX_VALUE
                for (p in src.keys) {
                    val d = abs(p - focus) * 2 + (if (p < focus) 1 else 0)
                    if (d < bestD) {
                        bestD = d
                        best = p
                    }
                }
                pos = best
                width = src.remove(best) ?: 0
                if (src === wanted) quick.remove(best)
            }
            try {
                val bmp = doc.render(pos, width)
                bmp.prepareToDraw() // upload to the GPU here, not on the UI thread (no scroll hitch)
                main.post { if (!stopped) deliver(pos, bmp) }
            } catch (e: OutOfMemoryError) {
                // skip this page, try the next one
            } catch (e: Exception) {
                // document closed or page unreadable
            }
        }
    }
}
