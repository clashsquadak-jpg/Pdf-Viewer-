package com.example.drivepdf

import android.graphics.Bitmap
import android.graphics.Color
import android.util.LruCache
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.min

class PageAdapter(
    private val doc: PdfDoc,
    itemWidth: Int,
    private val sideMargin: Int,
    private val vMargin: Int,
    seedPage: Int = -1,
    seed: Bitmap? = null
) : RecyclerView.Adapter<PageAdapter.VH>() {

    class VH(val img: ImageView) : RecyclerView.ViewHolder(img) {
        var index = -1
    }

    var itemWidth: Int = itemWidth
        private set

    private var contentWidth = (itemWidth - 2 * sideMargin).coerceAtLeast(1)
    private var quality = 1f
    private val holders = HashMap<Int, VH>()

    // prefix[i] = total height (px) of all pages before page i; used by the fast scroller
    private var prefix = LongArray(0)
    private var prefixDirty = true

    private val cache = object : LruCache<Int, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 4).toInt()
    ) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }

    init {
        // the first page was already rendered while the screen was getting ready
        if (seed != null && seedPage >= 0) cache.put(seedPage, seed)
    }

    private val renderer = PageRenderer(doc) { pos, bmp -> onRendered(pos, bmp) }

    private fun wantedWidth(): Int = min((contentWidth * quality).toInt(), 2400).coerceAtLeast(1)

    private fun needs(pos: Int): Boolean {
        val b = cache.get(pos)
        return b == null || b.width < wantedWidth() * 0.9f
    }

    /** Blank page: ask for a quick low-res preview first, then the sharp version. */
    private fun ask(pos: Int) {
        if (!needs(pos)) return
        val w = wantedWidth()
        if (cache.get(pos) == null) renderer.request(pos, (w / 3).coerceAtLeast(200), true)
        renderer.request(pos, w)
    }

    private fun onRendered(pos: Int, bmp: Bitmap) {
        val old = cache.get(pos)
        if (old == null || old.width < bmp.width) cache.put(pos, bmp)
        val h = holders[pos]
        if (h != null && h.index == pos) h.img.setImageBitmap(cache.get(pos))
    }

    // ---------- geometry (for the fast scroller) ----------

    private fun pageHeight(i: Int): Int {
        val s = doc.sizeOf(i)
        val ratio = if (s[0] > 0) s[1].toFloat() / s[0] else 1.414f
        return (contentWidth * ratio).toInt()
    }

    private fun ensurePrefix() {
        if (!prefixDirty && prefix.size == itemCount + 1) return
        val n = itemCount
        val a = LongArray(n + 1)
        for (i in 0 until n) a[i + 1] = a[i] + pageHeight(i) + 2 * vMargin
        prefix = a
        prefixDirty = false
    }

    /** Distance from the top of the document to the top of page [i], in px. */
    fun prefixAt(i: Int): Long {
        ensurePrefix()
        return prefix[i.coerceIn(0, itemCount)]
    }

    fun totalHeight(): Long {
        ensurePrefix()
        return prefix[itemCount]
    }

    /** Which page contains the point [y] px from the top of the document. */
    fun pageAtY(y: Long): Int {
        ensurePrefix()
        var lo = 0
        var hi = itemCount - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (prefix[mid] <= y) lo = mid else hi = mid - 1
        }
        return lo
    }

    // ---------- control ----------

    /** Tell the renderer which pages are on screen so it renders those first. */
    fun setWindow(first: Int, last: Int) {
        visFirst = first
        visLast = last
        renderer.setWindow(first, last)
    }

    private var visFirst = 0
    private var visLast = 0

    /** App left the foreground: stop rendering. */
    fun pause() = renderer.pause()

    /** App is back: re-request whatever is on screen and was not finished. */
    fun resume() {
        renderer.resume()
        for ((pos, _) in holders) ask(pos)
    }

    /** System is short on memory: drop cached pages that are not on screen. */
    fun trimMemory() {
        val keep = HashMap<Int, Bitmap>()
        for (p in visFirst..visLast) cache.get(p)?.let { keep[p] = it }
        cache.evictAll()
        for ((p, b) in keep) cache.put(p, b)
    }

    /** 1f = sharp at normal size, 2f = sharp when zoomed in. Old bitmaps stay visible until new ones arrive. */
    fun setQuality(q: Float) {
        if (q == quality) return
        quality = q
        // only what is on screen is re-rendered sharper; the rest follows when it scrolls closer
        for ((pos, _) in holders) {
            if (pos in visFirst..visLast && needs(pos)) renderer.request(pos, wantedWidth())
        }
    }

    /** The pane got wider or narrower (split view, rotation). */
    fun setItemWidth(w: Int) {
        itemWidth = w
        contentWidth = (w - 2 * sideMargin).coerceAtLeast(1)
        prefixDirty = true
        notifyDataSetChanged()
    }

    /** Real page sizes were read in the background. */
    fun onSizesChanged() {
        prefixDirty = true
        notifyDataSetChanged()
    }

    fun close() {
        renderer.stop()
        cache.evictAll()
        holders.clear()
    }

    override fun getItemCount() = doc.pageCount

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val iv = ImageView(parent.context)
        iv.scaleType = ImageView.ScaleType.FIT_XY
        iv.setBackgroundColor(Color.WHITE)
        return VH(iv)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        if (h.index >= 0 && holders[h.index] === h) holders.remove(h.index)
        h.index = position
        holders[position] = h

        val height = pageHeight(position)
        val old = h.img.layoutParams as? RecyclerView.LayoutParams
        if (old == null || old.width != contentWidth || old.height != height) {
            val lp = RecyclerView.LayoutParams(contentWidth, height)
            lp.setMargins(sideMargin, vMargin, sideMargin, vMargin)
            h.img.layoutParams = lp
        }

        h.img.setImageBitmap(cache.get(position))
        ask(position)
        // get the neighbours ready so scrolling never shows a blank page
        if (position + 1 < itemCount) ask(position + 1)
        if (position + 2 < itemCount) ask(position + 2)
        if (position - 1 >= 0) ask(position - 1)
    }

    override fun onViewRecycled(h: VH) {
        if (h.index >= 0 && holders[h.index] === h) holders.remove(h.index)
        h.index = -1
        h.img.setImageDrawable(null)
    }
}
