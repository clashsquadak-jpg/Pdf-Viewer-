package com.example.drivepdf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File
import kotlin.math.sqrt

class PdfDoc(file: File) {
    private val pfd: ParcelFileDescriptor =
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer: PdfRenderer = try {
        PdfRenderer(pfd)
    } catch (e: Exception) {
        pfd.close()
        throw e
    }
    private val lock = Any()

    @Volatile
    private var closed = false

    val pageCount: Int = renderer.pageCount
    private val sizeArr = arrayOfNulls<IntArray>(pageCount)

    init {
        if (pageCount > 0) sizeArr[0] = readSize(0)
    }

    private fun readSize(i: Int): IntArray = synchronized(lock) {
        if (closed) throw IllegalStateException("closed")
        val p = renderer.openPage(i)
        try {
            intArrayOf(p.width, p.height)
        } finally {
            p.close()
        }
    }

    /** Size of a page in PDF points. Pages whose size isn't known yet use page 1's size. */
    fun sizeOf(i: Int): IntArray = sizeArr[i] ?: sizeArr[0] ?: intArrayOf(595, 842)

    /** Reads the size of every page (slow for big PDFs, so call it in the background). */
    fun loadAllSizes(): Boolean {
        val first = sizeArr[0] ?: return false
        var changed = false
        for (i in 1 until pageCount) {
            if (closed) return false
            val s = try {
                readSize(i)
            } catch (e: Exception) {
                return changed
            }
            sizeArr[i] = s
            if (s[0] != first[0] || s[1] != first[1]) changed = true
        }
        return changed
    }

    fun render(index: Int, widthPx: Int): Bitmap = synchronized(lock) {
        if (closed) throw IllegalStateException("closed")
        val page = renderer.openPage(index)
        try {
            var w = widthPx.coerceAtLeast(1)
            var h = (w.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
            val maxPixels = 9_000_000.0
            if (w.toDouble() * h > maxPixels) {
                val f = sqrt(maxPixels / (w.toDouble() * h)).toFloat()
                w = (w * f).toInt().coerceAtLeast(1)
                h = (h * f).toInt().coerceAtLeast(1)
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        } finally {
            page.close()
        }
    }

    fun close() = synchronized(lock) {
        if (!closed) {
            closed = true
            try { renderer.close() } catch (_: Exception) {}
            try { pfd.close() } catch (_: Exception) {}
        }
    }
}
