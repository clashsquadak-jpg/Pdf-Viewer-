package com.example.drivepdf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File

class PdfDoc(file: File) {
    private val pfd: ParcelFileDescriptor =
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer: PdfRenderer = try {
        PdfRenderer(pfd)
    } catch (e: Exception) {
        pfd.close()
        throw e
    }
    private val lock = Any()
    @Volatile private var closed = false

    val pageCount: Int = renderer.pageCount

    /** width/height in PDF points for every page */
    val sizes: List<IntArray> = List(pageCount) { i ->
        val p = renderer.openPage(i)
        val s = intArrayOf(p.width, p.height)
        p.close()
        s
    }

    fun render(index: Int, widthPx: Int): Bitmap = synchronized(lock) {
        if (closed) throw IllegalStateException("closed")
        val page = renderer.openPage(index)
        try {
            val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        } finally {
            page.close()
        }
    }

    fun close() = synchronized(lock) {
        if (!closed) {
            closed = true
            try { renderer.close() } catch (_: Exception) {}
            try { pfd.close() } catch (_: Exception) {}
        }
    }
}
